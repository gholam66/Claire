#!/usr/bin/env bash
tmux kill-session -t "TDBot"
tmux kill-session -t "Helper"

echo "Start  Claire Launch (ربات در حال لانچ هست)"
sleep 1
echo "Base TDBot ( Claire v 1.0 )"
sleep 0.7
tmux new-session -d -s "TDBot" "./Data/TDBot"
tmux detach -s "TDBot"
echo "TDBot and Api Now Running (ربات با موفقیت لانچ شد)"
echo "... The terminal is Closed ..."
sleep 5
tmux new-session -d -s "Helper" "./Data/Helper"
tmux detach -s "Helper"

# Cleare

##### OPENED BY SPS TEAM 

### install

git clone https://github.com/MrRadsps/Cleare.git

cd  Cleare

chmod +x launch

./launch install

./launch config

#### after next cmd write you bot phone number and enter code for login 

./launch login

### Auto launch

killall screen && killall tmux && killall bash 

cd Cleare

screen ./launch cli

#### open another terminal and enter :

cd Cleare 

screen ./launch api

[OUR CHANNEL](https://t.me/joinchat/AAAAAE4lQOVgXks9iHubNw)

### Have Fun :)

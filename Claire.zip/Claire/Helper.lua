dofile("./Config.lua")
local http = require("socket.http")
local https = require("ssl.https")
local serpent = require("serpent")
local socket = require("socket")
local ltn12 = require("ltn12")
local URL = require("socket.url")
local json = (loadfile "./libs/JSON.lua")()
local redis1 = require("redis")
local redis = redis1.connect("127.0.0.1", 6379)
local Bot_Api = 'https://api.telegram.org/bot' ..token
local offset = 0 
redis:select(1)
minute = 60
hour = 3600
day = 86400
week = 604800 
MsgTime = os.time() - 5
-----Claire TDBot
function is_sudo(msg)
  local var = false
  for v,user in pairs(SUDO_ID) do
    if user == user then
      var = true
    end
  end
  return var
end
function is_Mod(chat_id,user_id)
local var = false
for v,user in pairs(SUDO_ID) do
if user == user_id then
var = true
end
end
local owner = redis:sismember('OwnerList:'..chat_id,user_id)
local hash = redis:sismember('ModList:'..chat_id,user_id)
if hash or owner then
var=  true
end
return var
end
  function is_Owner(chat_id,user_id)
local var = false
for v,user in pairs(SUDO_ID) do
if user== user_id then
var = true
end
end
local hash = redis:sismember('OwnerList:'..chat_id,user_id)
if hash then
var=  true
end
return var
end

local function vardump(value)
print(serpent.block(value, {comment = false}))
end
local function getUpdates()
local response = {}
local success, code, headers, status  = https.request{
url = Bot_Api .. '/getUpdates?timeout=20&limit=1&offset=' .. offset,
method = "POST",
 sink = ltn12.sink.table(response),
  }
local body = table.concat(response or {"no response"})
  if (success == 1) then
return json:decode(body)
  else
return nil, "Request Error"
 end
end
-----------------------
function AnswerInline(inline_query_id, query_id , title , description , text,parse_mode, keyboard)
local results = {{}}
 results[1].id = query_id
results[1].type = 'article'
results[1].description = description
results[1].title = title
results[1].message_text = text
results[1].parse_mode = parse_mode
Rep= Bot_Api .. '/answerInlineQuery?inline_query_id=' .. inline_query_id ..'&results=' .. URL.escape(json:encode(results))..'&parse_mode=&cache_time=' .. 1
if keyboard then
results[1].reply_markup = keyboard
Rep = Bot_Api.. '/answerInlineQuery?inline_query_id=' .. inline_query_id ..'&results=' .. URL.escape(json:encode(results))..'&parse_mode=Markdown&cache_time=' .. 1
end
https.request(Rep)
end
 function downloadFile(file_id, download_path)
if not file_id then return nil, "file_id not specified" end
if not download_path then return nil, "download_path not specified" end
local response = {}
local file_info = getFile(file_id)
local download_file_path = download_path or "downloads/" .. file_info.result.file_path
local download_file = io.open(download_file_path, "w")
if not download_file then return nil, "download_file could not be created"
else
local success, code, headers, status = https.request{
url = "https://api.telegram.org/file/bot" ..token.. "/" .. file_info.result.file_path,
--source = ltn12.source.string(body),
sink = ltn12.sink.file(download_file),
 }
local r = {
 success = true,
download_path = download_file_path,
file = file_info.result
 }
return r
end
end
function es_name(name) 
  if name:match('_') then
   name = name:gsub('_','')
  end
	if name:match('*') then
   name = name:gsub('*','')
  end
	if name:match('`') then
   name = name:gsub('`','')
  end
 return name
end
function SendInline(chat_id, text, keyboard, reply_to_message_id, markdown)
local url = Bot_Api.. '/sendMessage?chat_id=' .. chat_id
if reply_to_message_id then
url = url .. '&reply_to_message_id=' .. reply_to_message_id
end
if markdown == 'md' or markdown == 'markdown' then
url = url..'&parse_mode=Markdown'
elseif markdown == 'html' then
url = url..'&parse_mode=HTML'
end
url = url..'&text='..URL.escape(text)
url = url..'&disable_web_page_preview=true'
url = url..'&reply_markup='..URL.escape(JSON.encode(keyboard))
return https.request(url)
end
function getUserProfilePhotos(user_id, offset, limit)
local Rep = Bot_Api.. '/getUserProfilePhotos?user_id='..user_id
if offset then
Rep = Rep..'&offset='..offset
end
if limit then
if tonumber(limit) > 100 then 
limit = 100 
end
Rep = Rep..'&limit='..limit
end
return https.request(Rep)
end
function run_command(str)
  local cmd = io.popen(str)
  local result = cmd:read('*all')
  cmd:close()
  return result
end
function string:isempty()
  return self == nil or self == ''
end
function Leave(chat_id)
local Rep = Bot_API.. '/leaveChat?chat_id=' .. chat_id
return https.request(Rep)
end
function deletemessages(chat_id, message_id)
local Rep = Bot_Api..'/deletemessage?chat_id='..chat_id..'&message_id='..message_id
return https.request(Rep)
end
function Pin(chat_id, msg_id)
local Rep = Bot_Api..'/pinChatMessage?chat_id='..chat_id..'&message_id='..msg_id
return https.request(Rep)
end
function  changeChatDescription(chat_id, des)
local Rep = Bot_Api..'/setChatDescription?chat_id='..chat_id..'&description='..des
 return https.request(Rep)
end
function unpin(chat_id)
local Rep = Bot_Api..'/unpinChatMessage?chat_id='..chat_id
return https.request(Rep)
end 
function Unban(chat_id, user_id)
local Rep = Bot_Api.. '/unbanChatMember?chat_id=' .. chat_id .. '&user_id=' .. user_id
return https.request(Rep)
end
function CheckChatmember(chat_id, user_id)
local Rep = Bot_Api.. '/unbanChatMember?chat_id=' .. chat_id .. '&user_id=' .. user_id
return https.request(Rep)
end
function KickUser(user_id, chat_id)
local Rep = Bot_Api.. '/kickChatMember?chat_id=' .. chat_id .. '&user_id=' .. user_id
return https.request(Rep)
end
function get_http_file_name(url, headers)
  local file_name = url:match("[^%w]+([%.%w]+)$")
  file_name = file_name or url:match("[^%w]+(%w+)[^%w]+$")
  file_name = file_name or str:random(5)
  local content_type = headers["content-type"]
  local extension = nil
  if content_type then
    extension = mimetype.get_mime_extension(content_type)
  end
  if extension then
    file_name = file_name.."."..extension
  end
  local disposition = headers["content-disposition"]
  if disposition then
    file_name = disposition:match('filename=([^;]+)') or file_name
  end
  return file_name
end
function download_to_file(url, file_name)
  local respbody = {}
  local options = {
    url = url,
    sink = ltn12.sink.table(respbody),
    redirect = true
  }
  local response = nil
  if url:starts('https') then
    options.redirect = false
    response = {https.request(options)}
  else
    response = {http.request(options)}
  end
  local code = response[2]
  local headers = response[3]
  local status = response[4]
  if code ~= 200 then return nil end
  file_name = file_name or get_http_file_name(url, headers)
  local file_path = "data/"..file_name
  file = io.open(file_path, "w+")
  file:write(table.concat(respbody))
  file:close()
  return file_path
end
function sendPhoto(chat_id, file_id, reply_to_message_id, caption)
local Rep = Bot_Api.. '/sendPhoto?chat_id=' .. chat_id .. '&photo=' .. file_id
if reply_to_message_id then
Rep = Rep..'&reply_to_message_id='..reply_to_message_id
end
if caption then
Rep = Rep..'&caption='..URL.escape(caption)
end
return https.request(Rep)
end
function string:input()
if not self:find(' ') then
return false
end
return self:sub(self:find(' ')+1)
end

function getFile(file_id)
local Rep = Bot_Api.. '/getFile?file_id='..file_id
return https.request(Rep)
end
function EditInline( message_id, text, keyboard)
local Rep =  Bot_Api.. '/editMessageText?&inline_message_id='..message_id..'&text=' .. URL.escape(text)
Rep=Rep .. '&parse_mode=Markdown'
if keyboard then
Rep=Rep..'&reply_markup='..URL.escape(json:encode(keyboard))
 end
return https.request(Rep)
 end
function Alert(callback_query_id, text, show_alert)
local Rep = Bot_Api .. '/answerCallbackQuery?callback_query_id=' .. callback_query_id .. '&text=' .. URL.escape(text)
if show_alert then
Rep = Rep..'&show_alert=true'
end
https.request(Rep)
end
function sendText(chat_id, text, reply_to_message_id, markdown)
	local url = Bot_Api .. '/sendMessage?chat_id=' .. chat_id .. '&text=' .. URL.escape(text)
	if reply_to_message_id then
		url = url .. '&reply_to_message_id=' .. reply_to_message_id
	end
  if markdown == 'md' or markdown == 'markdown' then
    url = url..'&parse_mode=Markdown'
  elseif markdown == 'html' then
    url = url..'&parse_mode=HTML'
  end
	return https.request(url)
end
---------------------------

function menu(msg,chat_id)
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'مدیریت', callback_data = 'menugp:'..chat_id}
},
{
{text = 'بستن منو', callback_data = 'Exita:'..chat_id}
}
}
EditInline(msg.inline_id,' به بخش تنظیمات و مدیریت خوش امدید :\n'..msg.user_first..'',keyboard)
end

function setting1(msg,chat_id)
local edited = redis:get('Lock:Edit'..chat_id)
local fwded = redis:get('Lock:Forward:'..chat_id)
local arabiced = redis:get('Lock:Arabic:'..chat_id)
local englished = redis:get('Lock:English:'..chat_id)
local stickered = redis:get('Lock:Sticker:'..chat_id)
local linked = redis:get('Lock:Link'..chat_id)
local taged = redis:get('Lock:Tag:'..chat_id)
local hashtaged = redis:get('Lock:HashTag:'..chat_id)
local inlineed = redis:get('Lock:Inline:'..chat_id)
local video_noteed = redis:get('Lock:Video_note:'..chat_id)
local markdowned = redis:get('Lock:Markdown:'..chat_id)
local edit = (edited == "Warn") and "⚠" or ((edited == "Kick") and "🚫" or ((edited == "Mute") and "🔇" or ((edited == "Enable") and "🔐" or "🔓️")))
local fwd = (fwded == "Warn") and "⚠" or ((fwded == "Kick") and "🚫" or ((fwded == "Mute") and "🔇" or ((fwded == "Enable") and "🔐" or "🔓️")))
local arabic = (arabiced == "Warn") and "⚠" or ((arabiced == "Kick") and "🚫" or ((arabiced == "Mute") and "🔇" or ((arabiced == "Enable") and "🔐" or "🔓️")))
local english = (englished == "Warn") and "⚠" or ((englished == "Kick") and "🚫" or ((englished == "Mute") and "🔇" or ((englished == "Enable") and "🔐" or "🔓️")))
local sticker = (stickered == "Warn") and "⚠" or ((stickered == "Kick") and "🚫" or ((stickered == "Mute") and "🔇" or ((stickered == "Enable") and "🔐" or "🔓️")))
local link = (linked == "Warn") and "⚠" or ((linked == "Kick") and "🚫" or ((linked == "Mute") and "🔇" or ((linked == "Enable") and "🔐" or "🔓️")))
local tag = (taged == "Warn") and "⚠" or ((taged == "Kick") and "🚫" or ((taged == "Mute") and "🔇" or ((taged == "Enable") and "🔐" or "🔓️")))
local hashtag = (hashtaged == "Warn") and "⚠" or ((hashtaged == "Kick") and "🚫" or ((hashtaged == "Mute") and "🔇" or ((hashtaged == "Enable") and "🔐" or "🔓️")))
local inline = (inlineed == "Warn") and "⚠" or ((inlineed == "Kick") and "🚫" or ((inlineed == "Mute") and "🔇" or ((inlineed == "Enable") and "🔐" or "🔓️")))
local video_note = (video_noteed == "Warn") and "⚠" or ((video_noteed == "Kick") and "🚫" or ((video_noteed == "Mute") and "🔇" or ((video_noteed == "Enable") and "🔐" or "🔓️")))
local markdown = (markdowned == "Warn") and "⚠" or ((markdowned == "Kick") and "🚫" or ((markdowned == "Mute") and "🔇" or ((markdowned == "Enable") and "🔐" or "🔓️")))
if redis:get('Lock:Pin:'..chat_id) then
pin = '🔐'
else
pin = '🔓️' 
end
if redis:get('MuteAll:'..chat_id) then
muteall = '🔐'
else
muteall = '🔓' 
end
if redis:get('CheckBot:'..chat_id) then
TD = '🔐'
else
TD = '🔓'
end
if redis:get("Lock:Cmd"..chat_id) then
cmd = '🔐'
else
cmd = '🔓'
end
if redis:get('Lock:Flood:'..chat_id) then
flood = '🔐'
else
flood = '🔓'
end
if redis:get('Spam:Lock:'..chat_id) then
spam = '🔐'
else
spam = '🔓' 
end
if redis:get('automuteall'..chat_id) then
auto= '🔐'
else
auto= '🔓'
end
local text = ' تنظیمات گروه  در '..botname..' صفحه : 1'
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'لینک : '..link..'', callback_data = 'lock link:'..chat_id},
{text = 'ویرایش : '..edit..'', callback_data = 'lock edit:'..chat_id}
},{
{text = 'فونت : '..markdown..'', callback_data = 'lockmarkdown:'..chat_id}, 
{text = 'تگ : '..tag..'', callback_data = 'locktag:'..chat_id}
},{
{text = 'هشتگ : '..hashtag..'', callback_data = 'lockhashtag:'..chat_id},
{text = 'اینلاین : '..inline..'', callback_data = 'lockinline:'..chat_id}
},{
{text = 'فیلم سلفی : '..video_note..'', callback_data = 'lockvideo_note:'..chat_id},
{text = 'استیکر : '..sticker..'', callback_data = 'locksticker:'..chat_id}
},{
{text = 'فوروارد : '..fwd..'', callback_data = 'lockforward:'..chat_id}, 
{text = 'فارسی : '..arabic..'', callback_data = 'lockarabic:'..chat_id}
},{
{text = 'انگلیسی : '..english..'', callback_data = 'lockenglish:'..chat_id}, 
{text = 'سنجاق : '..pin..'', callback_data = 'lockpin'..chat_id}
},{
{text = 'فلود : '..flood..'', callback_data = 'lockflood:'..chat_id},
{text = 'اسپم : '..spam..'', callback_data = 'lockspam:'..chat_id}
},{
{text = 'دستورات : '..cmd..'', callback_data = 'lockcommand:'..chat_id}, 
{text = 'گروه : '..muteall..'', callback_data = 'muteall:'..chat_id}
},{
{text = 'خودکار : '..auto..'', callback_data = 'automuteall:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'menugp:'..chat_id},
{text = 'ادامه', callback_data = 'Mutelist:'..chat_id}
}
}
EditInline(msg.inline_id,text,keyboard)
end
function setting2(msg,chat_id)
local txtsed = redis:get('Mute:Text:'..chat_id)
local contacted = redis:get('Mute:Contact:'..chat_id)
local documented = redis:get('Mute:Document:'..chat_id)
local locationed = redis:get('Mute:Location:'..chat_id)
local voiceed = redis:get('Mute:Voice:'..chat_id)
local photoed = redis:get('Mute:Photo:'..chat_id)
local gameed = redis:get('Mute:Game:'..chat_id)
local musiced = redis:get('Mute:Music:'..chat_id)
local gifed = redis:get('Mute:Gif:'..chat_id)
local captioned = redis:get('Mute:Caption:'..chat_id)
local replyed = redis:get('Mute:Reply:'..chat_id)
local txts = (txtsed == "Warn") and "⚠" or ((txtsed == "Kick") and "🚫" or ((txtsed == "Mute") and "🔇" or ((txtsed == "Enable") and "🔐" or "🔓️")))
local contact = (contacted == "Warn") and "⚠" or ((contacted == "Kick") and "🚫" or ((contacted == "Mute") and "🔇" or ((contacted == "Enable") and "🔐" or "🔓️")))
local document = (documented == "Warn") and "⚠" or ((documented == "Kick") and "🚫" or ((documented == "Mute") and "🔇" or ((documented == "Enable") and "🔐" or "🔓️")))
local location = (locationed == "Warn") and "⚠" or ((locationed == "Kick") and "🚫" or ((locationed == "Mute") and "🔇" or ((locationed == "Enable") and "🔐" or "🔓️")))
local voice = (voiceed == "Warn") and "⚠" or ((voiceed == "Kick") and "🚫" or ((voiceed == "Mute") and "🔇" or ((voiceed == "Enable") and "🔐" or "🔓️")))
local photo = (photoed == "Warn") and "⚠" or ((photoed == "Kick") and "🚫" or ((photoed == "Mute") and "🔇" or ((photoed == "Enable") and "🔐" or "🔓️")))
local game = (gameed == "Warn") and "⚠" or ((gameed == "Kick") and "🚫" or ((gameed == "Mute") and "🔇" or ((gameed == "Enable") and "🔐" or "🔓️")))
local videoed = redis:get('Mute:Video:'..chat_id)
local video = (videoed == "Warn") and "⚠" or ((videoed == "Kick") and "🚫" or ((videoed == "Mute") and "🔇" or ((videoed == "Enable") and "🔐" or "🔓️")))
local music = (musiced == "Warn") and "⚠" or ((musiced == "Kick") and "🚫" or ((musiced == "Mute") and "🔇" or ((musiced == "Enable") and "🔐" or "🔓️")))
local gif = (gifed == "Warn") and "⚠" or ((gifed == "Kick") and "🚫" or ((gifed == "Mute") and "🔇" or ((gifed == "Enable") and "🔐" or "🔓️")))
local caption = (captioned == "Warn") and "⚠" or ((captioned == "Kick") and "🚫" or ((captioned == "Mute") and "🔇" or ((captioned == "Enable") and "🔐" or "🔓️")))
local reply = (replyed == "Warn") and "⚠" or ((replyed == "Kick") and "🚫" or ((replyed == "Mute") and "🔇" or ((replyed == "Enable") and "🔐" or "🔓️")))
if redis:get('Lock:TGservise:'..chat_id) then
tgservise = '🔐'
else
tgservise = '🔓️' 
end
if redis:get('Lock:Bot:'..chat_id) then
bot = '🔐'
else
bot = '🔓️' 
end
local text = 'تنظیمات گروه در '..botname..' صفحه : 2'
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'متن : '..txts..'', callback_data = 'mutetext:'..chat_id},
{text = 'عکس : '..photo..'', callback_data = 'mutephoto:'..chat_id}
},{
{text = 'مخاطب : '..contact..'', callback_data = 'mutecontact:'..chat_id},
{text = 'بازی  : '..game..'', callback_data = 'mutegame:'..chat_id}
},{
{text = 'فایل : '..document..'', callback_data = 'mutedocument:'..chat_id},
{text = 'فیلم : '..video..'', callback_data = 'mutevideo:'..chat_id}
},{
{text = 'موقعیت : '..location..'', callback_data = 'mutelocation:'..chat_id},
{text = 'آهنگ : '..music..'', callback_data = 'mutemusic:'..chat_id}
},{
{text = 'ویس : '..voice..'', callback_data = 'mutevoice:'..chat_id},
{text = 'عنوان : '..caption..'', callback_data = 'mutecaption:'..chat_id}
},{
{text = 'گیف : '..gif..'', callback_data = 'mutegif:'..chat_id},
{text = 'ریپلای : '..reply..'', callback_data = 'mutereply:'..chat_id}
},{
{text = 'ربات : '..bot..'', callback_data = 'lockbot:'..chat_id},
{text = 'سرویس  : '..tgservise..'', callback_data = 'locktgservise:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'Settings:'..chat_id},
{text = 'ادامه', callback_data = 'moresettings:'..chat_id}
}
}
EditInline(msg.inline_id,text,keyboard)
end
function setting3(msg,chat_id)
if redis:get("Flood:Status:"..chat_id) then
if redis:get("Flood:Status:"..chat_id) == "kickuser" then
Status = 'مسدود'
elseif redis:get("Flood:Status:"..chat_id) == "muteuser" then
Status = 'سایلنت'
elseif redis:get("Flood:Status:"..chat_id) == "deletemsg"  then
Status = 'حذف پیام'
end
else
Status = 'تنظیم نشده'
end
MSG_MAX = 6
if redis:get('Flood:Max:'..chat_id) then
MSG_MAX = redis:get('Flood:Max:'..chat_id)
end
CH_MAX = 200
if redis:get('NUM_CH_MAX:'..chat_id) then
CH_MAX = redis:get('NUM_CH_MAX:'..chat_id)
end
TIME_CHECK = 2
if redis:get('Flood:Time:'..chat_id) then
TIME_CHECK = redis:get('Flood:Time:'..chat_id)
end
Force_Time = 50
if redis:get('force:Time:'..chat_id) then
Force_Time = redis:get('force:Time:'..chat_id)
end
Force_Max = 2
if redis:get('force:Max:'..chat_id) then
Force_Max = redis:get('force:Max:'..chat_id)
end
Warn_Max = 1
if redis:get('Warn:Max:'..chat_id) then
Warn_Max = redis:get('Warn:Max:'..chat_id)
end
warn = 5
if redis:get('Warn:Max:'..chat_id) then
warn = redis:get('Warn:Max:'..chat_id)
end
if redis:get('forceAdd:'..chat_id) then
lockadd = 'فعال شد'
else
lockadd = 'غیرفعال شد' 
end
local text = ' تنظیمات گروه در '..botname..'  صفحه : 3'
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'وضعیت فلود : '..Status..'', callback_data = 'floodstatus:'..chat_id}
},{
{text='زمان برسی فلود : '..tostring(TIME_CHECK)..'',callback_data='Claire'..chat_id}
},{
{text='▲',callback_data='TIMEMAXup:'..chat_id},{text='▼',callback_data='TIMEMAXdown:'..chat_id}
},{
{text='تعداد فلود : '..tostring(MSG_MAX)..'',callback_data='Claire'..chat_id}
},{
{text='▲',callback_data='MSGMAXup:'..chat_id},{text='▼',callback_data='MSGMAXdown:'..chat_id}
},{
{text='تعداد اسپم : '..tostring(CH_MAX)..'',callback_data='Claire'..chat_id}
},{
{text='▲',callback_data='CHMAXup:'..chat_id},{text='▼',callback_data='CHMAXdown:'..chat_id}
},{
{text='حداکثر اخطار : '..tostring(Warn_Max)..'',callback_data='Claire'..chat_id}
},{
{text='▲',callback_data='Warn_Maxup:'..chat_id},{text='▼',callback_data='Warn_Maxdown:'..chat_id}
},{
{text = 'وضعیت اداجباری : '..lockadd..'', callback_data = 'lockadd:'..chat_id}
},{
{text='تعداد اداجباری : '..tostring(Force_Max)..'',callback_data='Claire'..chat_id}
},{
{text='▲',callback_data='Force_Maxup:'..chat_id},{text='▼',callback_data='Force_Maxdown:'..chat_id}
},{
{text='زمان پاکسازی  : '..tostring(Force_Time)..'',callback_data='Claire'..chat_id}
},{
{text='▲',callback_data='Force_Timeup:'..chat_id},{text='▼',callback_data='Force_Timedown:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'Mutelist:'..chat_id}
}
}
EditInline(msg.inline_id,text,keyboard)
end
function locks(msg,chat_id,name,red,cb,back)
	local temp = redis:get(red..chat_id)
	local st = (temp == "Warn") and "اخطار ⚠" or ((temp == "Kick") and "مسدود 🚫" or ((temp == "Mute") and "سایلنت 🔇" or ((temp == "Enable") and "فعال 🔐" or "غیرفعال 🔓")))
	name = name .. " : " .. st
	local keyboard = {}
	keyboard.inline_keyboard = {
		{
			{text = 'فعال', callback_data = cb.."enable:"..chat_id},
			{text = 'غیرفعال', callback_data = cb.."disable:"..chat_id}
		},
      	{
			{text = 'اخطار', callback_data = cb.."warn:"..chat_id},
			{text = 'سایلنت', callback_data = cb.."mute:"..chat_id}, 
			{text = 'مسدود', callback_data = cb.."kick:"..chat_id}
},{
			{text = 'بازگشت', callback_data = back..chat_id}
		}
	}
	EditInline(msg.inline_id,name,keyboard)
end
local function Running()
 while true do
local updates = getUpdates()
if updates and updates.result then
for i = 1, #updates.result do
local msg= updates.result[i]
offset = msg.update_id + 1
if msg.inline_query then
local TDBot = msg.inline_query
if TDBot.query:match('-%d+') then
chat_id = '-'..TDBot.query:match('%d+')
redis:set('chat',chat_id)
if TDBot.from.id == TD_ID or TDBot.from.id == Sudoid then
if redis:get('CheckBot:'..chat_id) then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'مدیریت', callback_data = 'menugp:'..chat_id}
},
{
{text = 'بستن منو', callback_data = 'Exita:'..chat_id}
}
}
AnswerInline(TDBot.id,'settings','Group settings',chat_id,'به بخش تنظیمات و مدیریت خوش امدید','Markdown',keyboard)
else
local keyboard = {}
keyboard.inline_keyboard = {{{text="کانال تیم ما",url="https://telegram.me/"..ChannelInline..""}}}			
AnswerInline(TDBot.id,'Not OK','Group Not Found',chat_id,' کاربر : '..TDBot.from.first_name..'شما دسترسی کافی برای این کار را ندارید','Markdown',keyboard)
end
end
end
end
if (updates.result) then
for i=1, #updates.result do
 local msg = updates.result[i]
offset = msg.update_id + 1
if msg.inline_query then
local TDBot = msg.inline_query
if TDBot.query:match("[Hh][Ee][Ll][Pp]") then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'راهنما سودو', callback_data = 'helpsudo:'..chat_id}
},
{
{text = 'راهنما مدیریتی', callback_data = 'helpmod:'..chat_id}
},
{
{text = 'راهنما قفلی', callback_data = 'helplock:'..chat_id}
},
{
{text = 'راهنما پاکسازی', callback_data = 'helpclean:'..chat_id}
},
{
{text = 'بستن منو', callback_data = 'Exit:'..chat_id}
}
}    
AnswerInline(TDBot.id,'helps','Bot Help',TDBot.query:match("[Hh][Ee][Ll][Pp]"),' به بخش راهنمای '..botname..' خوش آمدید\n\n ⚠توجه :\nدر صورتیکه پنل راهنما برا شما باز نشد ابتدا دستور فهرست را زده و سپس دوباره دستور راهنما را وارد کنید.\n \nموفق باشید:)','Markdown',keyboard)
end
end
end
end
if (updates.result) then
for i=1, #updates.result do
 local msg = updates.result[i]
offset = msg.update_id + 1
if msg.inline_query then
local TDBot = msg.inline_query
if TDBot.query:match("[Tt][Vv]") then
local keyboard = {}
keyboard.inline_keyboard = {
{
			{text = 'شـبــکـه➊ ', url = 'http://www.aparat.com/live/tv1'},
			{text = 'شبــکــه➋', url = 'http://www.aparat.com/live/tv2'}
		},
		{
			{text = 'شبــکــه➌', url = 'http://www.aparat.com/live/tv3'}
		},
		{
			{text = 'نـــمـــایـش', url = 'https://www.aparat.com/live/namayesh'},
			{text = 'تـمــاشـــا', url = 'https://www.aparat.com/live/hd'}
		},
		{
			{text = 'ای فـــیــلـم', url = 'https://www.aparat.com/live/ifilm'}
		},
		{
			{text = 'نـسـیــم', url = 'https://www.aparat.com/live/nasim'},
			{text = 'ورزش', url = 'https://www.aparat.com/live/varzesh'}
		},
		{
			{text = 'پـویـا', url = 'https://www.aparat.com/live/pouya'}
		},
		{
			{text = 'مـــسـتـــنــد', url = 'http://www.aparat.com/live/mostanad'},
			{text = 'افـــق', url = 'http://www.aparat.com/live/ofogh'}
		},
		{
{text = 'بستن منو', callback_data = 'Exit:'..chat_id}
}
}      
AnswerInline(TDBot.id,'tv','Bot tv',TDBot.query:match("[Tt][Vv]"),' به بخش تلویزیون '..botname..' خوش امدید','Markdown',keyboard)
end
end
end
end
if (updates.result) then
for i=1, #updates.result do
 local msg = updates.result[i]
offset = msg.update_id + 1
if msg.inline_query then
local TDBot = msg.inline_query
if TDBot.query:match("[Dd][Ee][Ll]") then
local keyboard = {}
keyboard.inline_keyboard = {
{
			{text = 'دیه نبینم برگردی', url = 'https://my.telegram.org/deactivate'}
}
}      
AnswerInline(TDBot.id,'Del','Bot del',TDBot.query:match("[Dd][Ee][Ll]"),'کاربر عزیز لینک دیلیت اکانت شما امادست','Markdown',keyboard)
end
end
end
end
if (updates.result) then
for i=1, #updates.result do
 local msg = updates.result[i]
offset = msg.update_id + 1
if msg.inline_query then 
local TDBot = msg.inline_query
if TDBot.query:match("[Ss][Uu][Pp][Pp][Oo][Rr][Tt][Ss]") then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text="پشتیبانی",url="https://telegram.me/"..Sudo..""},
{text="پیام رسان",url="https://telegram.me/"..PvSudo..""}
},
{
{text="گروه پشتیبانی",url="https://t.me/joinchat/"..LinkSuppoRt..""},
{text="کانال پشتیبانی",url="https://telegram.me/"..ChannelInline..""}
},
{
{text = 'بستن منو', callback_data = 'Exit:'..chat_id}
}
}
AnswerInline(TDBot.id,'Supports','Bot Supports',TDBot.query:match("[Ss][Uu][Pp][Pp][Oo][Rr][Tt][Ss]"),' به بخش پشتیبانی '..botname..' خوش امدید','Markdown',keyboard)
end
end
end
end
if (updates.result) then
for i=1, #updates.result do
 local msg = updates.result[i]
offset = msg.update_id + 1
if msg.inline_query then 
local TDBot = msg.inline_query
if TDBot.query:match("[Nn][Ee][Rr][Kk][Hh]") then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = '1 ماهه : 10تومن', callback_data = 'n1:'..chat_id}
},
{
{text = '2 ماهه : 18 تومن', callback_data = 'n2:'..chat_id},
{text = '3 ماهه : 25 تومن', callback_data = 'n3:'..chat_id}
}
}
AnswerInline(TDBot.id,'Nerkh','Bot nerkh',TDBot.query:match("[Nn][Ee][Rr][Kk][Hh]"),' ♨️ Claire v 1.0\n\nبرخی قابلیات های این ربات بی نظیر :\n\n1 - `دارای تمام قفل های تلگرامی`\n2 -` دارای قابلیات فان بی نظیر`\n3 -` دارای منوی مدیریتی قوی و زیبا`\n4 -` دارای قابلیات پاکسازی (پیام های گروه-لیست محدود-لیست مسدود-و...)`\n\n💵 نرخ فروش ربات ;\n\n`یکماهانه: 10 تومان`\n`دو ماه: 18 تومان`\n`سه ماه: 25 تومان`\n\nجهت خرید به '..UserSudo..' یا '..PvUserSudo..' مراجعه کنید','Markdown',keyboard)
end
end
end
end
if (updates.result) then
for i=1, #updates.result do
 local msg = updates.result[i]
offset = msg.update_id + 1
if msg.inline_query then 
local TDBot = msg.inline_query
if TDBot.query:match("[Cc][Aa][Rr][Dd]") then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'شماره کارت', callback_data = 'c1:'..chat_id}
},
{
{text = ''..cardnumber..'', callback_data = 'c2:'..chat_id}
},
{
{text = 'بنام '..name..'', callback_data = 'c3:'..chat_id}
}
}
AnswerInline(TDBot.id,'Card','Bot card',TDBot.query:match("[Cc][Aa][Rr][Dd]"),'شماره کارت جهت خرید ربات انتی اسپم ‌﴿'..botname..' ﴾\n\n'..cardnumber..'\n'..name..'\n'..bankname..'\n\nلطفا پس از پرداخت عکس از رسید و ایدی عددی گروهتون را برای '..UserSudo..' یا '..PvUserSudo..' ارسال کنید','Markdown',keyboard)
end
end
end
end
if (updates.result) then
for i=1, #updates.result do
 local msg = updates.result[i]
offset = msg.update_id + 1
if msg.inline_query then
local TDBot = msg.inline_query
if TDBot.query:match("[Pp][Aa][Yy]") then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'شماره کارت', callback_data = 'cardn:'..chat_id},
{text = 'نرخ ربات', callback_data = 'nbot:'..chat_id}
},
{
{text="خرید 1 ماهه",url="https://idpay.ir/"..idpay.."/100000"}
},
{
{text="خرید 2 ماهه",url="https://idpay.ir/"..idpay.."/180000"},
{text="خرید 3 ماهه",url="https://idpay.ir/"..idpay.."/250000"}
},
{ 
{text = 'بستن منو', callback_data = 'Exit:'..chat_id}
}
}      
AnswerInline(TDBot.id,'Pay','Bot pay',TDBot.query:match("[Pp][Aa][Yy]"),' به بخش خرید '..botname..' خوش امدید','Markdown',keyboard)
end
end
end
end
if (updates.result) then
for i=1, #updates.result do
 local msg = updates.result[i]
offset = msg.update_id + 1
if msg.inline_query then
local TDBot = msg.inline_query
if TDBot.query:match("[Pp]") then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = '1 ماهه : 10تومن', callback_data = 'n1:'..chat_id}
},
{
{text = '2 ماهه : 18 تومن', callback_data = 'n2:'..chat_id},
{text = '3 ماهه : 25 تومن', callback_data = 'n3:'..chat_id}
},
{
{text = 'شماره کارت', callback_data = 'c1:'..chat_id}
},
{
{text = ''..cardnumber..'', callback_data = 'c2:'..chat_id}
},
{
{text = 'بنام '..name..'', callback_data = 'c3:'..chat_id}
},
{
{text="خرید 1 ماهه",url="https://idpay.ir/"..idpay.."/100000"}
},
{
{text="خرید 2 ماهه",url="https://idpay.ir/"..idpay.."/180000"},
{text="خرید 3 ماهه",url="https://idpay.ir/"..idpay.."/250000"}
}
}      
AnswerInline(TDBot.id,'P','Bot p',TDBot.query:match("[Pp]"),' به بخش پرداخت '..botname..' خوش امدید','Markdown',keyboard)
end
end
end
end
if (updates.result) then
for i=1, #updates.result do
 local msg = updates.result[i]
offset = msg.update_id + 1
if msg.inline_query then
local TDBot = msg.inline_query
if TDBot.query:match("[Cc][Hh][Aa][Tt][Ss]") then

local page = 0

local keyboard = {}
keyboard.inline_keyboard = {}
local list = redis:smembers('group:')

if #list == 0 then
tt = 'لیست گروهها مدیریت '..botname..' خالی میباشد'
else
tt = 'به بخش مدیریت گروه های '..botname..' خوش امدید'
for k,v in pairs(list) do
local GroupsName = redis:get('StatsGpByName'..v)
local link = redis:get('Link:'..v)
if link then
temp = {{{text=GroupsName,url=link},{text=v,callback_data="gp:"..v}}}
else
temp = {{{text=GroupsName,callback_data="nolink"..v},{text=v,callback_data="gp:"..v}}}
end
if(k<6)then
for k,v in pairs(temp) do table.insert(keyboard.inline_keyboard,v) end
else
temp = {{{text= 'ادامه' ,callback_data = 'ChatsPage:1'}}}
for k,v in pairs(temp) do table.insert(keyboard.inline_keyboard,v) end
break;
end
end
temp = {{{text= 'بستن منو' ,callback_data = 'Exit:-1'}}}
for k,v in pairs(temp) do table.insert(keyboard.inline_keyboard,v) end
end

AnswerInline(TDBot.id,'chats','Chats',TDBot.query:match("[Cc][Hh][Aa][Tt][Ss]"),tt,'Markdown',keyboard)
end
end
 end
end
-----------------------------------
if Claire then
print(""..Claire.." : Sender : "..(msg.user_id or 'nil').."\nThis is [ TEXT ]")
end
if (updates.result) then
for i=1, #updates.result do
 local msg = updates.result[i]
offset = msg.update_id + 1
if msg.inline_query then
local TDBot = msg.inline_query
if TDBot.query:match('%d+') then
local keyboard = {}
keyboard.inline_keyboard = {{{text="کانال تیم ما",url="https://telegram.me/"..ChannelInline..""}}}
AnswerInline(TDBot.id,'Click To See User','Click To See User',TDBot.query:match('%d+'),'[برای دیدن اطلاعات کاربر کلیک کنید](tg://user?id='..TDBot.query:match('%d+')..')','Markdown',keyboard)
end
end
 end
end
 if (updates.result) then
 for i=1, #updates.result do
 local msg = updates.result[i]
offset = msg.update_id + 1
if msg.inline_query then
local TDBot = msg.inline_query
if TDBot.query:match("+(.*)") then
local link = TDBot.query:match("+(.*)")
AnswerInline(TDBot.id,'mod','GetLink','Url','[URL]('..link..')','Markdown',nil)
end
end
end
end
if msg.callback_query then
local TDBot = msg.callback_query
Claire = TDBot.data
msg.user_first= TDBot.from.first_name
chat_id = '-'..TDBot.data:match('(%d+)')
msg.inline_id = TDBot.inline_message_id
if not is_Mod(chat_id,TDBot.from.id) then
Alert(TDBot.id,'کاربر '..msg.user_first..' شما دسترسی کافی ندارید',true)
else
if Claire == 'Claire'..chat_id..'' then
Alert(TDBot.id,"اشتباه نزن چشمات ضعیف میشه")
else
if Claire == 'Menu:'..chat_id..'' then
menu(msg,chat_id)
end
if Claire == 'ChatsPage:'..string.sub(chat_id,2) then
local page = tonumber(string.sub(chat_id,2))
local keyboard = {}
keyboard.inline_keyboard = {}
local list = redis:smembers('group:')
local pages = math.floor(#list / 5)
if #list%5 > 0 then pages = pages + 1 end
pages = pages - 1

if #list == 0 then
tt = 'لیست گروهها مدیریت '..botname..' خالی میباشد'
else
tt = 'به بخش مدیریت گروه های '..botname..' خوش امدید'
for k,v in pairs(list) do
if (k > page*5) and (k < page*5+6) then
local GroupsName = redis:get('StatsGpByName'..v)
local link = redis:get('Link:'..v)
if link then
temp = {{{text=v,callback_data="gp:"..v},{text=GroupsName,url=link}}}
else
temp = {{{text=v,callback_data="gp:"..v},{text=GroupsName,callback_data="nolink"..v}}}
end
for k,v in pairs(temp) do table.insert(keyboard.inline_keyboard,v) end
end
end
if page == 0 then
if pages > 0 then
temp = {{{text= 'ادامه' ,callback_data = 'ChatsPage:1'}}}
for k,v in pairs(temp) do table.insert(keyboard.inline_keyboard,v) end
end
elseif page == pages then
temp = {{{text= 'بازگشت' ,callback_data = 'ChatsPage:'..(page-1)}}}
for k,v in pairs(temp) do table.insert(keyboard.inline_keyboard,v) end
else 
temp = {{{text= 'بازگشت' ,callback_data = 'ChatsPage:'..(page-1)},{text= 'ادامه' ,callback_data = 'ChatsPage:'..(page+1)}}}
for k,v in pairs(temp) do table.insert(keyboard.inline_keyboard,v) end
end
temp = {{{text= 'بستن منو' ,callback_data = 'Exit:-1'}}}
for k,v in pairs(temp) do table.insert(keyboard.inline_keyboard,v) end
end
EditInline(msg.inline_id,tt,keyboard) 
end
if Claire == 'menugp:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'تنظیمات گروه', callback_data = 'Settings:'..chat_id}
},
{
{text = 'مدیریت گروه', callback_data = 'groupinfo:'..chat_id},
},
{
{text = 'درباره '..botname..'', callback_data = 'cbot:'..chat_id}
},
{
{text = 'ورژن ربات : نسخه 1.0', callback_data = 'v:'..chat_id}
},
{
{text = 'بستن منو', callback_data = 'Exitb:'..chat_id}
}
}
EditInline(msg.inline_id,'به بخش منو '..botname..' خوش امدید',keyboard)
end
if Claire == 'Pay:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'شماره کارت', callback_data = 'cardn:'..chat_id},
{text = 'نرخ ربات', callback_data = 'nbot:'..chat_id}
},
{
{text="خرید 1 ماهه",url="https://idpay.ir/"..idpay.."/100000"}
},
{
{text="خرید 2 ماهه",url="https://idpay.ir/"..idpay.."/180000"},
{text="خرید 3 ماهه",url="https://idpay.ir/"..idpay.."/250000"}
},
{ 
{text = 'بستن منو', callback_data = 'Exit:'..chat_id}
}
}      
EditInline(msg.inline_id,'به منو خرید '..botname..' خوش امدید',keyboard)
end
if Claire == 'cardn:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'شماره کارت', callback_data = 'c1:'..chat_id}
},
{
{text = ''..cardnumber..'', callback_data = 'c2:'..chat_id}
},
{
{text = 'بنام '..name..'', callback_data = 'c3:'..chat_id}
},
{
{text = 'بازگشت', callback_data = 'Pay:'..chat_id}
}
}
EditInline(msg.inline_id,'شماره کارت جهت خرید ربات انتی اسپم ‌﴿'..botname..' ﴾\n\n'..cardnumber..'\n'..name..'\n'..bankname..'\n\nلطفا پس از پرداخت عکس از رسید و ایدی عددی گروهتون را برای '..UserSudo..' یا '..PvUserSudo..' ارسال کنید',keyboard)
end
if Claire == 'nbot:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = '1 ماهه : 10تومن', callback_data = 'n1:'..chat_id}
},
{
{text = '2 ماهه : 18 تومن', callback_data = 'n2:'..chat_id},
{text = '3 ماهه : 25 تومن', callback_data = 'n3:'..chat_id}
},
{
{text = 'بازگشت', callback_data = 'Pay:'..chat_id}
}
}
EditInline(msg.inline_id,'♨️ Claire v 1.0\n\nبرخی قابلیات های این ربات بی نظیر :\n\n1 - `دارای تمام قفل های تلگرامی`\n2 -` دارای قابلیات فان بی نظیر`\n3 -` دارای منوی مدیریتی قوی و زیبا`\n4 -` دارای قابلیات پاکسازی (پیام های گروه-لیست محدود-لیست مسدود-و...)`\n\n💵 نرخ فروش ربات ;\n\n`یکماهانه: 10 تومان`\n`دو ماه: 18 تومان`\n`سه ماه: 25 تومان`\n\nجهت خرید به '..UserSudo..' یا '..PvUserSudo..' مراجعه کنید',keyboard)
end
if Claire == 'cbot:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text="برنامه نویس",url="https://telegram.me/"..Sudo..""},
{text="پیام رسان",url="https://telegram.me/"..PvSudo..""}
},
{
{text="کانال ما",url="https://telegram.me/"..ChannelInline..""}
},
{
{text = 'بازگشت', callback_data = 'menugp:'..chat_id}
}
}
EditInline(msg.inline_id,'به بخش درباره '..botname..' خوش امدید',keyboard)
end
if Claire == 'help:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'راهنما سودو', callback_data = 'helpsudo:'..chat_id}
},
{
{text = 'راهنما مدیریتی', callback_data = 'helpmod:'..chat_id}
},
{
{text = 'راهنما قفلی', callback_data = 'helplock:'..chat_id}
},
{
{text = 'راهنما پاکسازی', callback_data = 'helpclean:'..chat_id}
},
{
{text = 'بستن منو', callback_data = 'Exit:'..chat_id}
}
}
EditInline(msg.inline_id,'به بخش راهنما '..botname..' خوش امدید',keyboard)
end
if Claire == 'helplock:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'لینک', callback_data = 'hlink:'..chat_id},
{text = 'ویرایش', callback_data = 'hedit:'..chat_id},
{text = 'فونت', callback_data = 'hfont:'..chat_id}
},{
{text = 'تگ', callback_data = 'htag:'..chat_id},
{text = 'هشتگ', callback_data = 'hhtag:'..chat_id},
{text = 'اینلاین', callback_data = 'hinline:'..chat_id}
},{
{text = 'فیلم سلفی', callback_data = 'hnote:'..chat_id},
{text = 'استیکر', callback_data = 'hsticker:'..chat_id},
{text = 'فوروارد', callback_data = 'hforward:'..chat_id}
},{
{text = 'فارسی', callback_data = 'hfa:'..chat_id},
{text = 'انگلیسی', callback_data = 'hen:'..chat_id},
{text = 'سنجاق', callback_data = 'hpin:'..chat_id}
},{
{text = 'فلود', callback_data = 'hflod:'..chat_id},
{text = 'اسپم', callback_data = 'hspm:'..chat_id},
{text = 'دستورات', callback_data = 'hcmd:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'help:'..chat_id},
			{text = '•••', callback_data = 'xx:'..chat_id},
{text = 'ادامه', callback_data = 'helplocks:'..chat_id}
}
}
EditInline(msg.inline_id,'به بخش راهنما قفلی '..botname..' خوش امدید\nصفحه : 1',keyboard)
end
if Claire == 'helplocks:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'عکس', callback_data = 'hphoto:'..chat_id},
{text = 'مخاطب', callback_data = 'hcontact:'..chat_id},
{text = 'بازی', callback_data = 'hgame:'..chat_id}
},{
{text = 'فایل', callback_data = 'hfile:'..chat_id},
{text = 'فیلم', callback_data = 'hvideo:'..chat_id},
{text = 'موقعیت' , callback_data = 'hlocation:'..chat_id}
},{
{text = 'آهنگ', callback_data = 'hmusic:'..chat_id},
{text = 'ویس', callback_data = 'hvoice:'..chat_id},
{text = 'عنوان', callback_data = 'hcaption:'..chat_id}
},{
{text = 'گیف', callback_data = 'hgif:'..chat_id},
{text = 'ریپلای', callback_data = 'hreply:'..chat_id},
{text = 'ربات', callback_data = 'hbot:'..chat_id}
},{
{text = 'سرویس', callback_data = 'htgservise:'..chat_id},
{text = 'گروه', callback_data = 'hall:'..chat_id},
{text = 'متن', callback_data = 'htxt:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplock:'..chat_id}
}
}
EditInline(msg.inline_id,'به بخش راهنما قفلی '..botname..' خوش امدید\nصفحه : 2',keyboard)
end
if Claire == 'hcmd:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن دستورات', callback_data = 'unnlock:'..chat_id},
{text = 'قفل دستورات', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock cmd', callback_data = 'lock:'..chat_id},
{text = 'Unlock cmd', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplock:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن دستورات توسط ربات:\n•  `قفل دستورات` \n•  `Lock cmd`   \n•  `بازکردن دستورات` \n•  `Unlock cmd`   \n⇜ این دستور برای قفل و بازکردن دستورات در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'hspm:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن اسپم', callback_data = 'unnlock:'..chat_id},
{text = 'قفل اسپم', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock spam', callback_data = 'lock:'..chat_id},
{text = 'Unlock spam', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplock:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن اسپم توسط ربات:\n•  `قفل اسپم` \n•  `Lock spam`   \n•  `بازکردن اسپم` \n•  `Unlock spam`   \n⇜ این دستور برای قفل و بازکردن اسپم در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'hflod:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن فلود', callback_data = 'unnlock:'..chat_id},
{text = 'قفل فلود', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock flood', callback_data = 'lock:'..chat_id},
{text = 'Unlock flood', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplock:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن فلود توسط ربات:\n•  `قفل فلود` \n•  `Lock flood`   \n•  `بازکردن فلود` \n•  `Unlock flood`   \n⇜ این دستور برای قفل و بازکردن فلود در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'hpin:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن سنجاق', callback_data = 'unnlock:'..chat_id},
{text = 'قفل سنجاق', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock pin', callback_data = 'lock:'..chat_id},
{text = 'Unlock pin', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplock:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن سنجاق توسط ربات:\n•  `قفل سنجاق` \n•  `Lock pin`   \n•  `بازکردن سنجاق` \n•  `Unlock pin`   \n⇜ این دستور برای قفل و بازکردن سنجاق در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'hforward:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن فوروارد', callback_data = 'unnlock:'..chat_id},
{text = 'قفل فوروارد', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock forward', callback_data = 'lock:'..chat_id},
{text = 'Unlock forward', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplock:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن فوروارد توسط ربات:\n•  `قفل فوروارد` \n•  `Lock forward`   \n•  `بازکردن فوروارد` \n•  `Unlock forward`   \n⇜ این دستور برای قفل و بازکردن فوروارد در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'hfa:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن فارسی', callback_data = 'unnlock:'..chat_id},
{text = 'قفل فارسی', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock farsi', callback_data = 'lock:'..chat_id},
{text = 'Unlock farsi', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplock:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن فارسی توسط ربات:\n•  `قفل فارسی` \n•  `Lock farsi`   \n•  `بازکردن فارسی` \n•  `Unlock farsi`   \n⇜ این دستور برای قفل و بازکردن فارسی در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'hen:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن انگلیسی', callback_data = 'unnlock:'..chat_id},
{text = 'قفل انگلیسی', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock english', callback_data = 'lock:'..chat_id},
{text = 'Unlock english', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplock:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن انگلیسی توسط ربات:\n•  `قفل انگلیسی` \n•  `Lock english`   \n•  `بازکردن انگلیسی` \n•  `Unlock english`   \n⇜ این دستور برای قفل و بازکردن انگلیسی در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'htxt:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن متن', callback_data = 'unnlock:'..chat_id},
{text = 'قفل متن', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock text', callback_data = 'lock:'..chat_id},
{text = 'Unlock text', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplocks:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن متن توسط ربات:\n•  `قفل متن` \n•  `Lock text`   \n•  `بازکردن متن` \n•  `Unlock text`   \n⇜ این دستور برای قفل و بازکردن متن در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'htgservise:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن سرویس', callback_data = 'unnlock:'..chat_id},
{text = 'قفل سرویس', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock service', callback_data = 'lock:'..chat_id},
{text = 'Unlock service', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplocks:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن سرویس توسط ربات:\n•  `قفل سرویس` \n•  `Lock service`   \n•  `بازکردن سرویس` \n•  `Unlock service`   \n⇜ این دستور برای قفل و بازکردن سرویس در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'hphoto:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن عکس', callback_data = 'unnlock:'..chat_id},
{text = 'قفل عکس', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock photo', callback_data = 'lock:'..chat_id},
{text = 'Unlock photo', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplocks:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن عکس توسط ربات:\n•  `قفل عکس` \n•  `Lock photo`   \n•  `بازکردن عکس` \n•  `Unlock photo`   \n⇜ این دستور برای قفل و بازکردن عکس در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'hcontact:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن مخاطب', callback_data = 'unnlock:'..chat_id},
{text = 'قفل مخاطب', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock contact', callback_data = 'lock:'..chat_id},
{text = 'Unlock contact', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplocks:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن مخاطب توسط ربات:\n•  `قفل مخاطب` \n•  `Lock contact`   \n•  `بازکردن مخاطب` \n•  `Unlock contact`   \n⇜ این دستور برای قفل و بازکردن مخاطب در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'hreply:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن ریپلای', callback_data = 'unnlock:'..chat_id},
{text = 'قفل ریپلای', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock reply', callback_data = 'lock:'..chat_id},
{text = 'Unlock reply', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplocks:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن ریپلای توسط ربات:\n•  `قفل ریپلای` \n•  `Lock reply`   \n•  `بازکردن ریپلای` \n•  `Unlock reply`   \n⇜ این دستور برای قفل و بازکردن ریپلای در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'hfile:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن فایل', callback_data = 'unnlock:'..chat_id},
{text = 'قفل فایل', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock file', callback_data = 'lock:'..chat_id},
{text = 'Unlock file', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplocks:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن فایل توسط ربات:\n•  `قفل فایل` \n•  `Lock file`   \n•  `بازکردن فایل` \n•  `Unlock file`   \n⇜ این دستور برای قفل و بازکردن فایل در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'hgif:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن گیف', callback_data = 'unnlock:'..chat_id},
{text = 'قفل گیف', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock gif', callback_data = 'lock:'..chat_id},
{text = 'Unlock gif', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplocks:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن گیف توسط ربات:\n•  `قفل گیف` \n•  `Lock gif`   \n•  `بازکردن گیف` \n•  `Unlock gif`   \n⇜ این دستور برای قفل و بازکردن گیف در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'hbot:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن ربات', callback_data = 'unnlock:'..chat_id},
{text = 'قفل ربات', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock bot', callback_data = 'lock:'..chat_id},
{text = 'Unlock bot', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplocks:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن ربات توسط ربات:\n•  `قفل ربات` \n•  `Lock bot`   \n•  `بازکردن ربات` \n•  `Unlock bot`   \n⇜ این دستور برای قفل و بازکردن ربات در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'hcaption:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن رسانه', callback_data = 'unnlock:'..chat_id},
{text = 'قفل رسانه', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock caption', callback_data = 'lock:'..chat_id},
{text = 'Unlock caption', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplocks:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن رسانه توسط ربات:\n•  `قفل رسانه` \n•  `Lock caption`   \n•  `بازکردن رسانه` \n•  `Unlock caption`   \n⇜ این دستور برای قفل و بازکردن رسانه در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'hlocation:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن مکان', callback_data = 'unnlock:'..chat_id},
{text = 'قفل مکان', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock location', callback_data = 'lock:'..chat_id},
{text = 'Unlock location', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplocks:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن مکان توسط ربات:\n•  `قفل مکان` \n•  `Lock location`   \n•  `بازکردن مکان` \n•  `Unlock location`   \n⇜ این دستور برای قفل و بازکردن مکان در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'hmusic:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن آهنگ', callback_data = 'unnlock:'..chat_id},
{text = 'قفل آهنگ', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock music', callback_data = 'lock:'..chat_id},
{text = 'Unlock music', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplocks:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن آهنگ توسط ربات:\n•  `قفل آهنگ` \n•  `Lock music`   \n•  `بازکردن آهنگ` \n•  `Unlock music`   \n⇜ این دستور برای قفل و بازکردن آهنگ در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'hvideo:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن فیلم', callback_data = 'unnlock:'..chat_id},
{text = 'قفل فیلم', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock video', callback_data = 'lock:'..chat_id},
{text = 'Unlock video', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplocks:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن فیلم توسط ربات:\n•  `قفل فیلم` \n•  `Lock video`   \n•  `بازکردن فیلم` \n•  `Unlock video`   \n⇜ این دستور برای قفل و بازکردن فیلم در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'hall:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن گروه', callback_data = 'unnlock:'..chat_id},
{text = 'قفل گروه', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock group', callback_data = 'lock:'..chat_id},
{text = 'Unlock group', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplocks:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن گروه توسط ربات:\n•  `قفل گروه` \n•  `Lock group`   \n•  `بازکردن گروه` \n•  `Unlock group`   \n⇜ این دستور برای قفل و بازکردن گروه در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'hvoice:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن ویس', callback_data = 'unnlock:'..chat_id},
{text = 'قفل ویس', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock voice', callback_data = 'lock:'..chat_id},
{text = 'Unlock voice', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplocks:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن ویس توسط ربات:\n•  `قفل ویس` \n•  `Lock voice`   \n•  `بازکردن ویس` \n•  `Unlock voice`   \n⇜ این دستور برای قفل و بازکردن ویس در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'hgame:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن بازی', callback_data = 'unnlock:'..chat_id},
{text = 'قفل بازی', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock game', callback_data = 'lock:'..chat_id},
{text = 'Unlock game', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplocks:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن بازی توسط ربات:\n•  `قفل بازی` \n•  `Lock game`   \n•  `بازکردن بازی` \n•  `Unlock game`   \n⇜ این دستور برای قفل و بازکردن بازی در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'hsticker:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن استیکر', callback_data = 'unnlock:'..chat_id},
{text = 'قفل استیکر', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock sticker', callback_data = 'lock:'..chat_id},
{text = 'Unlock sticker', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplock:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن استیکر توسط ربات:\n•  `قفل استیکر` \n•  `Lock sticker`   \n•  `بازکردن استیکر` \n•  `Unlock sticker`   \n⇜ این دستور برای قفل و بازکردن استیکر در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'hnote:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن سلفی', callback_data = 'unnlock:'..chat_id},
{text = 'قفل سلفی', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock self', callback_data = 'lock:'..chat_id},
{text = 'Unlock self', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplock:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن ویرایش توسط ربات:\n•  `قفل سلفی` \n•  `Lock self`   \n•  `بازکردن سلفی` \n•  `Unlock self`   \n⇜ این دستور برای قفل و بازکردن سلفی در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'hlink:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن لینک', callback_data = 'unnlock:'..chat_id},
{text = 'قفل لینک', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock link', callback_data = 'lock:'..chat_id},
{text = 'Unlock link', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplock:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن لینک توسط ربات:\n•  `قفل لینک` \n•  `Lock link`   \n•  `بازکردن لینک` \n•  `Unlock link`   \n⇜ این دستور برای قفل و بازکردن لینک در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'htag:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن تگ', callback_data = 'unnlock:'..chat_id},
{text = 'قفل تگ', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock tag', callback_data = 'lock:'..chat_id},
{text = 'Unlock tag', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplock:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن تگ توسط ربات:\n•  `قفل تگ` \n•  `Lock tag`   \n•  `بازکردن تگ` \n•  `Unlock tag`   \n⇜ این دستور برای قفل و بازکردن تگ در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'hedit:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن ویرایش', callback_data = 'unnlock:'..chat_id},
{text = 'قفل ویرایش', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock edit', callback_data = 'lock:'..chat_id},
{text = 'Unlock edit', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplock:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن ویرایش توسط ربات:\n•  `قفل ویرایش` \n•  `Lock edit`   \n•  `بازکردن ویرایش` \n•  `Unlock edit`   \n⇜ این دستور برای قفل و بازکردن ویرایش در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'hhtag:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن هشتگ', callback_data = 'unnlock:'..chat_id},
{text = 'قفل هشتگ', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock hashtag', callback_data = 'lock:'..chat_id},
{text = 'Unlock hashtag', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplock:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن هشتگ توسط ربات:\n•  `قفل هشتگ` \n•  `Lock hashtag`   \n•  `بازکردن هشتگ` \n•  `Unlock hashtag`   \n⇜ این دستور برای قفل و بازکردن هشتگ در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'hfont:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن فونت', callback_data = 'unnlock:'..chat_id},
{text = 'قفل فونت', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock font', callback_data = 'lock:'..chat_id},
{text = 'Unlock font', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplock:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن فونت توسط ربات:\n•  `قفل فونت` \n•  `Lock font`   \n•  `بازکردن فونت` \n•  `Unlock font`   \n⇜ این دستور برای قفل و بازکردن فونت در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'hinline:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بازکردن اینلاین', callback_data = 'unnlock:'..chat_id},
{text = 'قفل اینلاین', callback_data = 'llock:'..chat_id}
},{
{text = 'Lock inline', callback_data = 'lock:'..chat_id},
{text = 'Unlock inline', callback_data = 'unlock:'..chat_id}
},{
{text = 'بازگشت', callback_data = 'helplock:'..chat_id}
}
}
EditInline(msg.inline_id,'↫ برای قفل و بازکردن فونت توسط ربات:\n•  `قفل اینلاین` \n•  `Lock inline`   \n•  `بازکردن اینلاین` \n•  `Unlock inline`   \n⇜ این دستور برای قفل و بازکردن اینلاین در گروه توسط ربات میباشد.',keyboard)
end
if Claire == 'helpsudo:'..chat_id..'' then
local help =[[
● راهنما سودو ربات ]]..botname..[[ ●
﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍

↫ برای تنظیم کردن فرد به عنوان سودو ربات:
•  `افزودن سودو` [ یوزرنیم | ایدی | ریپلای ]
•  `Setsudo` [username | id | reply]
➖➖➖➖➖➖➖➖➖➖➖
↫ برای حذف کرد فرد از عنوان سودو ربات:
•  `حذف سودو` [یوزرنیم | ایدی | ریپلای]
•  `Remsudo` [username | id | reply]
➖➖➖➖➖➖➖➖➖➖➖
↫ برای نصب ربات درگروه توسط ربات:
•  `نصب` 
•  `Add` 
➖➖➖➖➖➖➖➖➖➖➖
↫ برای حذف نصب درگروه توسط ربات:
•  `لغو نصب`
•  `Rem` 
➖➖➖➖➖➖➖➖➖➖➖
↫ برای دریافت لیست سودو توسط ربات:
•  `لیست سودو` 
•  `Sudolist` 
➖➖➖➖➖➖➖➖➖➖➖
↫ برای تنظیم کردن شارژ گروه توسط ربات:
•  `شارژ` روز
•  `Charge` dey 
➖➖➖➖➖➖➖➖➖➖➖
↫ برای نامحدود کردن شارژ گروه توسط ربات:
•  `نامحدود`
•  `Full`
➖➖➖➖➖➖➖➖➖➖➖
↫ برای دریافت لیست گروه ها توسط ربات:
•  `لیست گروه ها` 
•  `Gplist `
➖➖➖➖➖➖➖➖➖➖➖
↫ برای دریافت لیست گروه ها در پیوی شما توسط ربات:
•  `گروه ها خصوصی` 
•  `Gplist pv` 
➖➖➖➖➖➖➖➖➖➖➖
↫ برای مسدود همگانی از گروه ها توسط ربات:
•  `بن ال` [یوزرنیم | ایدی | ریپلای]
•  `Banall` [username | id | reply]
➖➖➖➖➖➖➖➖➖➖➖
↫ برای حذف از مسدود همگانی از گروه ها توسط ربات:
•  `حذف بن ال` [یوزرنیم | ایدی | ریپلای]
•  `Unbanall` [username | id | reply]
➖➖➖➖➖➖➖➖➖➖➖
↫ برای تنظیم مالک گروه توسط ربات:
•  `مالک` [یوزرنیم | ایدی | ریپلای]
• `Setowner` [username | id | reply]
➖➖➖➖➖➖➖➖➖➖➖
↫ برای تنظیم حذف مالک گروه توسط ربات:
•  `حذف مالک` [یوزرنیم | ایدی | ریپلای]
• `Remowner` [username | id | reply]
➖➖➖➖➖➖➖➖➖➖➖
↫ برای دریافت آمار توسط ربات:
•  `آمار ` 
•  `Stats `
➖➖➖➖➖➖➖➖➖➖➖
↫ برای بروز کردن آمار ربات:
•  `ریست`
•  `Reset`
➖➖➖➖➖➖➖➖➖➖➖
↫ برای دریافت لیست مسدود همگانی توسط ربات:
•  `لیست بن ال` 
•  `Gbanlist`
➖➖➖➖➖➖➖➖➖➖➖
↫ برای ارتقا اعضا گروه فرد توسط ربات:
•  `پیکربندی` 
•  `Config`
➖➖➖➖➖➖➖➖➖➖➖
↫ برای پاکسازی مالکان توسط ربات:
•  `پاکسازی لیست مالکان` 
•  `Clean owners`   
➖➖➖➖➖➖➖➖➖➖➖
↫ برای پاکسازی لیست مسدود همگانی توسط ربات:
•  `پاکسازی لیست بن ال` 
•  `Clean gbans`
➖➖➖➖➖➖➖➖➖➖➖
↫ برای تنظیم مقام کاربر توسط ربات:
•  `تنظیم مقام` متن
•  `Setrank` text
➖➖➖➖➖➖➖➖➖➖➖
↫ برای فعالسازی جوین اجباری توسط ربات:
•  `جوین اجباری` [فعال | غیرفعال]
•  `Forcejoin` [enable | disable]
➖➖➖➖➖➖➖➖➖➖➖
]]
local keyboard = {}
	keyboard.inline_keyboard = {
		{
			{text = 'بازگشت', callback_data = 'help:'..chat_id}
		}
	}
EditInline(msg.inline_id,help,keyboard)
end
if Claire == 'helpmod:'..chat_id..'' then
local help =[[

● راهنما مدیریتی ربات  ]]..botname..[[ ●
﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍

↫ برای تنظیم کرد فرد به عنوان مدیر ربات:
•  `مدیر` یوزرنیم | ایدی | ریپلای
• `Promote` username | id | reply
➖➖➖➖➖➖➖➖➖➖➖
↫ برای حذف کرد فرد از عنوان مدیر ربات:
•  `حذف مدیر` یوزرنیم | ایدی | ریپلای
•  `Demote` username | id | reply
➖➖➖➖➖➖➖➖➖➖➖
↫ برای تنظیم کردن زمان ارسال پیام مکرر توسط ربات:
•  `تنظیم زمان بررسی` 1-10
•  `Setfloodtime ` 1-10
➖➖➖➖➖➖➖➖➖➖➖
↫ برای تنظیم کردن حداکثر حروف ارسالی توسط ربات:
•  `تنظیم کاراکتر` عدد
•  `Setspam` num
➖➖➖➖➖➖➖➖➖➖➖
↫ برای تنظیم کردن حداکثر پیام مکرر توسط ربات:
•  `تنظیم پیام مکرر`  1 | 50
•  `Setflood` 1 | 50
➖➖➖➖➖➖➖➖➖➖➖
↫ برای تنظیم کردن وضعیت آن توسط ربات:
•  `تنظیم پیام مکرر`  [حذف پیام | سکوت |اخراج]
•  `Setflood` [delmsg | mute | kick]
➖➖➖➖➖➖➖➖➖➖➖
↫ برای سکوت کردن فرد توسط ربات:
•  `سکوت` [عدد] | یوزرنیم | ایدی | ریپلای
•  `Mute` [num] username | id | reply
➖➖➖➖➖➖➖➖➖➖➖
↫ برای حذف سکوت کردن فرد توسط ربات:
•  `حذف سکوت` یوزرنیم | ایدی | ریپلای
•  `Unmute` username| id| reply
➖➖➖➖➖➖➖➖➖➖➖
↫ برای اخراج کردن فرد توسط ربات:
•  `اخراج` یوزرنیم | ایدی | ریپلای
• `Kick` username| id| reply
➖➖➖➖➖➖➖➖➖➖➖
↫ برای مسدود کردن فرد توسط ربات:
•  `بن` یوزرنیم | ایدی | ریپلای
•  `Ban` username| id| reply
➖➖➖➖➖➖➖➖➖➖➖
↫ برای رفع مسدود کردن فرد توسط ربات:
•  `حذف بن` یوزرنیم | ایدی | ریپلای
•  `Unban` username| id| reply
➖➖➖➖➖➖➖➖➖➖➖
↫ برای اخطار دادن به فرد توسط ربات:
•  `اخطار` یوزرنیم | ایدی | ریپلای
•  `Warn` username| id| reply
➖➖➖➖➖➖➖➖➖➖➖
↫ برای حذف کردن اخطار فرد توسط ربات:
•  `حذف اخطار` یوزرنیم | ایدی | ریپلای
•  `Unwarn` username| id| reply
➖➖➖➖➖➖➖➖➖➖➖
↫ برای تنظیم کردن حداکثر اخطار های ربات:
•  `تنظیم اخطار` 1-20
•  `Setwarn` 1-20
➖➖➖➖➖➖➖➖➖➖➖
↫ برای افزودن افراد از لیست ویژه:
•  `ویژه`  یوزرنیم | ایدی |ریپلی 
•  `Vip` username | id |reply
 ➖➖➖➖➖➖➖➖➖➖➖
↫ برای حذف افراد از لیست ویژه:
•  `حذف ویژه` یوزرنیم | ایدی |ریپلی 
•  `remVip`  username | id |reply
➖➖➖➖➖➖➖➖➖➖➖
↫ برای نمایش ایدی شخص توسط ربات:
•  `ایدی` ریپلای
•  `Id ` reply
➖➖➖➖➖➖➖➖➖➖➖
↫ برای تنظیم کردن قوانین ربات:
•  `تنظیم قوانین` متن
•  `Setrules` text
➖➖➖➖➖➖➖➖➖➖➖
↫ برای تنظیم کردن نام گروه توسط ربات:
•  `تنظیم نام` متن
•  `Setname` text
➖➖➖➖➖➖➖➖➖➖➖
↫ برای تنظیم کردن لینک گروه در ربات:
•  `تنظیم لینک` ریپلای
•  `Setlink` reply
➖➖➖➖➖➖➖➖➖➖➖
↫ برای تنظیم کردن درباره گروه:
•  `تنظیم درباره` متن
•  `Setabout` text
➖➖➖➖➖➖➖➖➖➖➖
↫ برای تنظیم کردن متن خوشآمد گروه:
•  `تنظیم خوشامد` متن
•  `Setwelcome ` text
➖➖➖➖➖➖➖➖➖➖➖
↫ برای ممنوع کردن کلمه ای در گروه:
• `فیلتر` کلمه
• `Filter` word
➖➖➖➖➖➖➖➖➖➖➖
↫ برای آزاد کردن کلمه ای در گروه:
• `حذف فیلتر` کلمه
• `Unfilter` word
➖➖➖➖➖➖➖➖➖➖➖
]]
local keyboard = {}
	keyboard.inline_keyboard = {
		{
			{text = 'بازگشت', callback_data = 'help:'..chat_id},
			{text = 'ادامه', callback_data = 'helpmo:'..chat_id}
		}
	}
EditInline(msg.inline_id,help,keyboard)
end
if Claire == 'helpmo:'..chat_id..'' then
local help =[[
● ادامه راهنما مدیریتی ربات  ]]..botname..[[ ●•
﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍

‌↫ برای سنجاق کردن متن در گروه توسط ربات:
• `سنجاق` ریپلای
• `Pin` reply
➖➖➖➖➖➖➖➖➖➖➖
‌↫ برای حذف سنجاق کردن متن در گروه توسط ربات:
• `حذف سنجاق`
• `Unpin`
➖➖➖➖➖➖➖➖➖➖➖
‌↫ برای فعال و غیرفعال کردن خوشآمد ربات:
• `خوشامد` [فعال | غیرفعال]
•  `Welcome` [enable | disable] 
➖➖➖➖➖➖➖➖➖➖➖
‌↫ برای نمایش تنظیمات اعمال شده در گروه:
• `تنظیمات`
• `Settings`
➖➖➖➖➖➖➖➖➖➖➖
‌↫ برای نمایش سکوت شده های گروه:
• `لیست سکوت`
• `Mutelist` 
➖➖➖➖➖➖➖➖➖➖➖
‌↫ برای نمایش کلمات ممنوع شده گروه:
• `لیست فیلتر`
• `Filterlist`
➖➖➖➖➖➖➖➖➖➖➖
‌↫ برای نمایش افراد مسدود شده گروه:
• `لیست مسدود`
• `Banlist`
➖➖➖➖➖➖➖➖➖➖➖
‌↫ برای نمایش مالکین گروه:
• `لیست مالکان`
• `Ownerlist`
➖➖➖➖➖➖➖➖➖➖➖
‌↫ برای نمایش مدیران گروه:
• `لیست مدیران`
• `Modlist`
➖➖➖➖➖➖➖➖➖➖➖
‌↫ برای نمایش افراد ویژه  شده گروه:
• `لیست ویژه`
• `Viplist`
➖➖➖➖➖➖➖➖➖➖➖
‌↫ برای نمایش قوانین گروه:
• `قوانین`
• `Rules`
➖➖➖➖➖➖➖➖➖➖➖
‌↫ برای نمایش درباره گروه:
• `درباره`
• `About`
➖➖➖➖➖➖➖➖➖➖➖
‌↫ برای نمایش لینک گروه:
• `لینک`
• `Link`
➖➖➖➖➖➖➖➖➖➖➖
↫ برای فعال سازی و اداجباری گروه توسط ربات:
• `قفل اداجباری`
• `Lock‌ add`
➖➖➖➖➖➖➖➖➖➖➖
↫ برای غیرفعال سازی و اداجباری گروه توسط ربات:
• `بازکردن اداجباری`
• `Unlock add`
➖➖➖➖➖➖➖➖➖➖➖
↫ برای تنظیم اداجباری گروه توسط ربات:
• `تنظیم اداجباری` [همه | کاربران جدید]
• `Setadd` [all | newuser]
➖➖➖➖➖➖➖➖➖➖➖
↫ برای تنظیم تعداد اداجباری گروه توسط ربات:
• `تنظیم اداجباری` 1 | 10
• `Setadd` 1 | 10
➖➖➖➖➖➖➖➖➖➖➖
↫ برای تنظیم قفل گروه توسط ربات:
• `قفل گروه` [محدود | حذف پیام]
• `Lock group` [rcd | delmsg]
➖➖➖➖➖➖➖➖➖➖➖
↫ برای  تنظیم قفل خودکار توسط ربات:
• `تنظیم قفل خودکار` 00:00-07:00
• `setautolock` 00:00-07:00
➖➖➖➖➖➖➖➖➖➖➖
↫ برای فعالسازی قفل خودکار توسط ربات:
• `قفل خودکار` [فعال | غیرفعال]
•  `Autolock` [enable | disable] 
➖➖➖➖➖➖➖➖➖➖➖
↫ برای دریافت پنل مدیریتی ربات:
• `فهرست` (خصوصی) 
• `menu` (pv) 
➖➖➖➖➖➖➖➖➖➖➖
↫ برای دریافت راهنمای ربات:
• `راهنما` (خصوصی)
• `help` (pv)
➖➖➖➖➖➖➖➖➖➖➖
↫ برای دریافت بخش پشتیبانی توسط ربات:
• `پشتیبانی` (خصوصی)
• `Support` (pv)
➖➖➖➖➖➖➖➖➖➖➖
↫ برای دریافت لینک خرید ربات توسط ربات:
• `خرید` (خصوصی)
• `Pay` (pv)
➖➖➖➖➖➖➖➖➖➖➖
↫ برای دریافت لینک دیلیت اکانت توسط ربات:
• `دیلیت اکانت` (خصوصی)
• `Deleteacc` (pv)
➖➖➖➖➖➖➖➖➖➖➖
↫ برای اطلاع از انلاینی ربات خود توسط ربات:
• `پینگ`
• `Ping`
➖➖➖➖➖➖➖➖➖➖➖
↫ برای دریافت اطلاعات اطلاعات گروه توسط ربات:
• `اطلاعات گروه`
• `Gpinfo` 
➖➖➖➖➖➖➖➖➖➖➖
↫ برای دریافت اطلاعات خود توسط ربات:
• `اطلاعات من`
• `Me`
➖➖➖➖➖➖➖➖➖➖➖
↫ برای دریافت مقام خود توسط ربات:
• `مقام من`
• `Rank`
➖➖➖➖➖➖➖➖➖➖➖
↫ برای دریافت ساعت توسط ربات:
• `زمان`
• `Time`
➖➖➖➖➖➖➖➖➖➖➖
↫ برای دریافت پروفایل خود توسط ربات:
• `پروفایل` عدد
• `Getpro` num
➖➖➖➖➖➖➖➖➖➖➖
↫ برای دریافت اعتبار ربات توسط ربات:
• `اعتبار` 
• `Expire` 
➖➖➖➖➖➖➖➖➖➖➖
]]
local keyboard = {}
	keyboard.inline_keyboard = {
		{
			{text = 'بازگشت', callback_data = 'helpmod:'..chat_id}
		}
	}
EditInline(msg.inline_id,help,keyboard)
end
if Claire == 'helpclean:'..chat_id..'' then
local help =[[
● راهنما پاکسازی ربات ]]..botname..[[ ●
﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍

↫ برای پاک کردن تمام پیام های گروه توسط ربات:
• `پاکسازی پیام ها`
• `Del`
➖➖➖➖➖➖➖➖➖➖➖
↫ برای پاک کردن تعداد پیام های گروه توسط ربات:
• `پاکسازی` 1-1000
• `Delall` 1-1000
➖➖➖➖➖➖➖➖➖➖➖
↫ برای پاک کردن تمام پیام های یک شخص توسط ربات:
• `پاکسازی پیام` ریپلای
• `Deluser` replay 
➖➖➖➖➖➖➖➖➖➖➖
↫ برای پاک کردن لیست اخطارها ها توسط ربات:
• `پاکسازی لیست اخطار`
• `Clean warns`
➖➖➖➖➖➖➖➖➖➖➖
↫ برای پاک کردن لیست سکوت شده ها توسط ربات:
• `پاکسازی لیست سکوت`
• `Clean silents`
➖➖➖➖➖➖➖➖➖➖➖
↫ برای پاک کردن کلمات فیلتر شده توسط ربات:
• `پاکسازی لیست فیلتر`
• `Clean filters`
➖➖➖➖➖➖➖➖➖➖➖
↫ برای پاک کردن لیست ویژه شده توسط ربات:
• `پاکسازی لیست ویژه`
• `Clean vip`
➖➖➖➖➖➖➖➖➖➖➖
↫ برای پاک کردن لیست بن شده ها توسط ربات:
• `پاکسازی لیست مسدود`
• `Clean bans`
➖➖➖➖➖➖➖➖➖➖➖
↫ برای پاک کردن لیست مدیرهای ربات:
• `پاکسازی لیست مدیران`
• `Clean mods`
➖➖➖➖➖➖➖➖➖➖➖
↫ برای پاک کردن  محدود های گروه در ربات:
• `پاکسازی لیست محدود`
• `Clean res`
➖➖➖➖➖➖➖➖➖➖➖
↫ برای پاک کردن دیلیت شده ها توسط ربات:
• `پاکسازی دلیت اکانت ها`
• `Clean deleted`
➖➖➖➖➖➖➖➖➖➖➖
↫ برای پاک کردن ربات ها توسط ربات:
• `پاکسازی ربات ها`
• `Clean bots`
➖➖➖➖➖➖➖➖➖➖➖
]]
local keyboard = {}
	keyboard.inline_keyboard = {
		{
			{text = 'بازگشت', callback_data = 'help:'..chat_id}
		}
	}
EditInline(msg.inline_id,help,keyboard)
end
if Claire == 'Exita:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بله بسته شود', callback_data = 'Exit:'..chat_id}
},
{
{text = 'خیر ورود به منو', callback_data = 'menugp:'..chat_id}
}
}
EditInline(msg.inline_id,'ایا تمایل به بستن منو '..botname..' را دارید',keyboard)
end
if Claire == 'Exitb:' ..chat_id..'' then
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = 'بله', callback_data = 'Exit:'..chat_id},
{text = 'خیر', callback_data = 'menugp:'..chat_id}
}
}
EditInline(msg.inline_id,'ایا تمایل به بستن منو '..botname..' را دارید',keyboard)
end
if Claire == 'management:'..chat_id then
management(msg,chat_id)
end
if Claire == 'Settings:'..chat_id then
setting1(msg,chat_id)
end
if Claire == 'moresettings:'..chat_id then
setting3(msg,chat_id)
end
if Claire == 'Mutelist:'..chat_id then
setting2(msg,chat_id)
end
if Claire == 'Exit:'..chat_id..'' then
EditInline(msg.inline_id,'هلپر '..botname..' بسته شد',keyboard)
end
-------------------------------------
if Claire == 'lock edit:'..chat_id then
	locks(msg,chat_id,' قفل ویرایش پیام','Lock:Edit','lock edit:','Settings:')
end
if Claire == 'lock edit:kick:'..chat_id then
	redis:set('Lock:Edit'..chat_id,"Kick")
	locks(msg,chat_id,' قفل ویرایش پیام','Lock:Edit','lock edit:','Settings:')
end
if Claire == 'lock edit:warn:'..chat_id then
	redis:set('Lock:Edit'..chat_id,"Warn")
	locks(msg,chat_id,' قفل ویرایش پیام','Lock:Edit','lock edit:','Settings:')
end
if Claire == 'lock edit:mute:'..chat_id then
	redis:set('Lock:Edit'..chat_id,"Mute")
	locks(msg,chat_id,' قفل ویرایش پیام','Lock:Edit','lock edit:','Settings:')
end
if Claire == 'lock edit:enable:'..chat_id then
	redis:set('Lock:Edit'..chat_id,"Enable")
	locks(msg,chat_id,' قفل ویرایش پیام','Lock:Edit','lock edit:','Settings:')
end
if Claire == 'lock edit:disable:'..chat_id then
	redis:del('Lock:Edit'..chat_id)
	locks(msg,chat_id,' قفل ویرایش پیام','Lock:Edit','lock edit:','Settings:')
end
-------------------------------------
if Claire == 'lock link:'..chat_id then
	locks(msg,chat_id,' قفل ارسال لینک','Lock:Link','lock link:','Settings:')
end
if Claire == 'lock link:kick:'..chat_id then
	redis:set('Lock:Link'..chat_id,"Kick")
	locks(msg,chat_id,' قفل ارسال لینک','Lock:Link','lock link:','Settings:')
end
if Claire == 'lock link:warn:'..chat_id then
	redis:set('Lock:Link'..chat_id,"Warn")
	locks(msg,chat_id,' قفل ارسال لینک','Lock:Link','lock link:','Settings:')
end
if Claire == 'lock link:mute:'..chat_id then
	redis:set('Lock:Link'..chat_id,"Mute")
	locks(msg,chat_id,' قفل ارسال لینک','Lock:Link','lock link:','Settings:')
end
if Claire == 'lock link:enable:'..chat_id then
	redis:set('Lock:Link'..chat_id,"Enable")
	locks(msg,chat_id,' قفل ارسال لینک','Lock:Link','lock link:','Settings:')
end
if Claire == 'lock link:disable:'..chat_id then
	redis:del('Lock:Link'..chat_id)
	locks(msg,chat_id,' قفل ارسال لینک','Lock:Link','lock link:','Settings:')
end
-------------------------------------
if Claire == 'lockmarkdown:'..chat_id then
	locks(msg,chat_id,' قفل  نشانه گذاری','Lock:Markdown:','lockmarkdown:','Settings:')
end
if Claire == 'lockmarkdown:kick:'..chat_id then
	redis:set('Lock:Markdown:'..chat_id,"Kick")
	locks(msg,chat_id,' قفل  نشانه گذاری','Lock:Markdown:','lockmarkdown:','Settings:')
end
if Claire == 'lockmarkdown:warn:'..chat_id then
	redis:set('Lock:Markdown:'..chat_id,"Warn")
	locks(msg,chat_id,' قفل  نشانه گذاری','Lock:Markdown:','lockmarkdown:','Settings:')
end
if Claire == 'lockmarkdown:mute:'..chat_id then
	redis:set('Lock:Markdown:'..chat_id,"Mute")
	locks(msg,chat_id,' قفل  نشانه گذاری','Lock:Markdown:','lockmarkdown:','Settings:')
end
if Claire == 'lockmarkdown:enable:'..chat_id then
	redis:set('Lock:Markdown:'..chat_id,"Enable")
	locks(msg,chat_id,' قفل  نشانه گذاری','Lock:Markdown:','lockmarkdown:','Settings:')
end
if Claire == 'lockmarkdown:disable:'..chat_id then
	redis:del('Lock:Markdown:'..chat_id)
	locks(msg,chat_id,' قفل  نشانه گذاری','Lock:Markdown:','lockmarkdown:','Settings:')
end
-------------------------------------
if Claire == 'lockforward:'..chat_id then
	locks(msg,chat_id,' قفل فوروارد','Lock:Forward:','lockforward:','Settings:')
end
if Claire == 'lockforward:kick:'..chat_id then
	redis:set('Lock:Forward:'..chat_id,"Kick")
	locks(msg,chat_id,' قفل فوروارد','Lock:Forward:','lockforward:','Settings:')
end
if Claire == 'lockforward:warn:'..chat_id then
	redis:set('Lock:Forward:'..chat_id,"Warn")
	locks(msg,chat_id,' قفل فوروارد','Lock:Forward:','lockforward:','Settings:')
end
if Claire == 'lockforward:mute:'..chat_id then
	redis:set('Lock:Forward:'..chat_id,"Mute")
	locks(msg,chat_id,' قفل فوروارد','Lock:Forward:','lockforward:','Settings:')
end
if Claire == 'lockforward:enable:'..chat_id then
	redis:set('Lock:Forward:'..chat_id,"Enable")
	locks(msg,chat_id,' قفل فوروارد','Lock:Forward:','lockforward:','Settings:')
end
if Claire == 'lockforward:disable:'..chat_id then
	redis:del('Lock:Forward:'..chat_id)
	locks(msg,chat_id,' قفل فوروارد','Lock:Forward:','lockforward:','Settings:')
end
-------------------------------------
if Claire == 'lockarabic:'..chat_id then
	locks(msg,chat_id,' قفل فارسی','Lock:Arabic:','lockarabic:','Settings:')
end
if Claire == 'lockarabic:kick:'..chat_id then
	redis:set('Lock:Arabic:'..chat_id,"Kick")
	locks(msg,chat_id,' قفل فارسی','Lock:Arabic:','lockarabic:','Settings:')
end
if Claire == 'lockarabic:warn:'..chat_id then
	redis:set('Lock:Arabic:'..chat_id,"Warn")
	locks(msg,chat_id,' قفل فارسی','Lock:Arabic:','lockarabic:','Settings:')
end
if Claire == 'lockarabic:mute:'..chat_id then
	redis:set('Lock:Arabic:'..chat_id,"Mute")
	locks(msg,chat_id,' قفل فارسی','Lock:Arabic:','lockarabic:','Settings:')
end
if Claire == 'lockarabic:enable:'..chat_id then
	redis:set('Lock:Arabic:'..chat_id,"Enable")
	locks(msg,chat_id,' قفل فارسی','Lock:Arabic:','lockarabic:','Settings:')
end
if Claire == 'lockarabic:disable:'..chat_id then
	redis:del('Lock:Arabic:'..chat_id)
	locks(msg,chat_id,' قفل فارسی','Lock:Arabic:','lockarabic:','Settings:')
end
-------------------------------------
if Claire == 'lockenglish:'..chat_id then
	locks(msg,chat_id,' قفل انگلیسی','Lock:English:','lockenglish:','Settings:')
end
if Claire == 'lockenglish:kick:'..chat_id then
	redis:set('Lock:English:'..chat_id,"Kick")
	locks(msg,chat_id,' قفل انگلیسی','Lock:English:','lockenglish:','Settings:')
end
if Claire == 'lockenglish:warn:'..chat_id then
	redis:set('Lock:English:'..chat_id,"Warn")
	locks(msg,chat_id,' قفل انگلیسی','Lock:English:','lockenglish:','Settings:')
end
if Claire == 'lockenglish:mute:'..chat_id then
	redis:set('Lock:English:'..chat_id,"Mute")
	locks(msg,chat_id,' قفل انگلیسی','Lock:English:','lockenglish:','Settings:')
end
if Claire == 'lockenglish:enable:'..chat_id then
	redis:set('Lock:English:'..chat_id,"Enable")
	locks(msg,chat_id,' قفل انگلیسی','Lock:English:','lockenglish:','Settings:')
end
if Claire == 'lockenglish:disable:'..chat_id then
	redis:del('Lock:English:'..chat_id)
	locks(msg,chat_id,' قفل انگلیسی','Lock:English:','lockenglish:','Settings:')
end
-------------------------------------
if Claire == 'locktgservise:'..chat_id then
if redis:get('Lock:TGservise:'..chat_id) then
redis:del('Lock:TGservise:'..chat_id)
Alert(TDBot.id," قفل  حدف پیام ورود خروج غیرفعال شد ")
else
redis:set('Lock:TGservise:'..chat_id,true)
Alert(TDBot.id," قفل  حدف پیام ورود خروج فعال شد")
end
setting2(msg,chat_id)
end
-------------------------------------
if Claire == 'locksticker:'..chat_id then
	locks(msg,chat_id,' قفل استیکر','Lock:Sticker:','locksticker:','Settings:')
end
if Claire == 'locksticker:kick:'..chat_id then
	redis:set('Lock:Sticker:'..chat_id,"Kick")
	locks(msg,chat_id,' قفل استیکر','Lock:Sticker:','locksticker:','Settings:')
end
if Claire == 'locksticker:warn:'..chat_id then
	redis:set('Lock:Sticker:'..chat_id,"Warn")
	locks(msg,chat_id,' قفل استیکر','Lock:Sticker:','locksticker:','Settings:')
end
if Claire == 'locksticker:mute:'..chat_id then
	redis:set('Lock:Sticker:'..chat_id,"Mute")
	locks(msg,chat_id,' قفل استیکر','Lock:Sticker:','locksticker:','Settings:')
end
if Claire == 'locksticker:enable:'..chat_id then
	redis:set('Lock:Sticker:'..chat_id,"Enable")
	locks(msg,chat_id,' قفل استیکر','Lock:Sticker:','locksticker:','Settings:')
end
if Claire == 'locksticker:disable:'..chat_id then
	redis:del('Lock:Sticker:'..chat_id)
	locks(msg,chat_id,' قفل استیکر','Lock:Sticker:','locksticker:','Settings:')
end
-------------------------------------
if Claire == 'mutetext:'..chat_id then
	locks(msg,chat_id,' قفل متن','Mute:Text:','mutetext:','Mutelist:')
end
if Claire == 'mutetext:kick:'..chat_id then
	redis:set('Mute:Text:'..chat_id,"Kick")
	locks(msg,chat_id,' قفل متن','Mute:Text:','mutetext:','Mutelist:')
end
if Claire == 'mutetext:warn:'..chat_id then
	redis:set('Mute:Text:'..chat_id,"Warn")
	locks(msg,chat_id,' قفل متن','Mute:Text:','mutetext:','Mutelist:')
end
if Claire == 'mutetext:mute:'..chat_id then
	redis:set('Mute:Text:'..chat_id,"Mute")
	locks(msg,chat_id,' قفل متن','Mute:Text:','mutetext:','Mutelist:')
end
if Claire == 'mutetext:enable:'..chat_id then
	redis:set('Mute:Text:'..chat_id,"Enable")
	locks(msg,chat_id,' قفل متن','Mute:Text:','mutetext:','Mutelist:')
end
if Claire == 'mutetext:disable:'..chat_id then
	redis:del('Mute:Text:'..chat_id)
	locks(msg,chat_id,' قفل متن','Mute:Text:','mutetext:','Mutelist:')
end
-------------------------------------
if Claire == 'mutecontact:'..chat_id then
	locks(msg,chat_id,' قفل مخاطب','Mute:Contact:','mutecontact:','Mutelist:')
end
if Claire == 'mutecontact:kick:'..chat_id then
	redis:set('Mute:Contact:'..chat_id,"Kick")
	locks(msg,chat_id,' قفل مخاطب','Mute:Contact:','mutecontact:','Mutelist:')
end
if Claire == 'mutecontact:warn:'..chat_id then
	redis:set('Mute:Contact:'..chat_id,"Warn")
	locks(msg,chat_id,' قفل مخاطب','Mute:Contact:','mutecontact:','Mutelist:')
end
if Claire == 'mutecontact:mute:'..chat_id then
	redis:set('Mute:Contact:'..chat_id,"Mute")
	locks(msg,chat_id,' قفل مخاطب','Mute:Contact:','mutecontact:','Mutelist:')
end
if Claire == 'mutecontact:enable:'..chat_id then
	redis:set('Mute:Contact:'..chat_id,"Enable")
	locks(msg,chat_id,' قفل مخاطب','Mute:Contact:','mutecontact:','Mutelist:')
end
if Claire == 'mutecontact:disable:'..chat_id then
	redis:del('Mute:Contact:'..chat_id)
	locks(msg,chat_id,' قفل مخاطب','Mute:Contact:','mutecontact:','Mutelist:')
end
-------------------------------------
if Claire == 'mutegame:'..chat_id then
	locks(msg,chat_id,' قفل بازی','Mute:Game:','mutegame:','Mutelist:')
end
if Claire == 'mutegame:kick:'..chat_id then
	redis:set('Mute:Game:'..chat_id,"Kick")
	locks(msg,chat_id,' قفل بازی','Mute:Game:','mutegame:','Mutelist:')
end
if Claire == 'mutegame:warn:'..chat_id then
	redis:set('Mute:Game:'..chat_id,"Warn")
	locks(msg,chat_id,' قفل بازی','Mute:Game:','mutegame:','Mutelist:')
end
if Claire == 'mutegame:mute:'..chat_id then
	redis:set('Mute:Game:'..chat_id,"Mute")
	locks(msg,chat_id,' قفل بازی','Mute:Game:','mutegame:','Mutelist:')
end
if Claire == 'mutegame:enable:'..chat_id then
	redis:set('Mute:Game:'..chat_id,"Enable")
	locks(msg,chat_id,' قفل بازی','Mute:Game:','mutegame:','Mutelist:')
end
if Claire == 'mutegame:disable:'..chat_id then
	redis:del('Mute:Game:'..chat_id)
	locks(msg,chat_id,' قفل بازی','Mute:Game:','mutegame:','Mutelist:')
end
------------------------------------- 
if Claire == 'mutephoto:'..chat_id then
	locks(msg,chat_id,' قفل عکس','Mute:Photo:','mutephoto:','Mutelist:')
end
if Claire == 'mutephoto:kick:'..chat_id then
	redis:set('Mute:Photo:'..chat_id,"Kick")
	locks(msg,chat_id,' قفل عکس','Mute:Photo:','mutephoto:','Mutelist:')
end
if Claire == 'mutephoto:warn:'..chat_id then
	redis:set('Mute:Photo:'..chat_id,"Warn")
	locks(msg,chat_id,' قفل عکس','Mute:Photo:','mutephoto:','Mutelist:')
end
if Claire == 'mutephoto:mute:'..chat_id then
	redis:set('Mute:Photo:'..chat_id,"Mute")
	locks(msg,chat_id,' قفل عکس','Mute:Photo:','mutephoto:','Mutelist:')
end
if Claire == 'mutephoto:enable:'..chat_id then
	redis:set('Mute:Photo:'..chat_id,"Enable")
	locks(msg,chat_id,' قفل عکس','Mute:Photo:','mutephoto:','Mutelist:')
end
if Claire == 'mutephoto:disable:'..chat_id then
	redis:del('Mute:Photo:'..chat_id)
	locks(msg,chat_id,' قفل عکس','Mute:Photo:','mutephoto:','Mutelist:')
end
-------------------------------------
if Claire == 'mutedocument:'..chat_id then
	locks(msg,chat_id,' قفل فایل','Mute:Document:','mutedocument:','Mutelist:')
end
if Claire == 'mutedocument:kick:'..chat_id then
	redis:set('Mute:Document:'..chat_id,"Kick")
	locks(msg,chat_id,' قفل فایل','Mute:Document:','mutedocument:','Mutelist:')
end
if Claire == 'mutedocument:warn:'..chat_id then
	redis:set('Mute:Document:'..chat_id,"Warn")
	locks(msg,chat_id,' قفل فایل','Mute:Document:','mutedocument:','Mutelist:')
end
if Claire == 'mutedocument:mute:'..chat_id then
	redis:set('Mute:Document:'..chat_id,"Mute")
	locks(msg,chat_id,' قفل فایل','Mute:Document:','mutedocument:','Mutelist:')
end
if Claire == 'mutedocument:enable:'..chat_id then
	redis:set('Mute:Document:'..chat_id,"Enable")
	locks(msg,chat_id,' قفل فایل','Mute:Document:','mutedocument:','Mutelist:')
end
if Claire == 'mutedocument:disable:'..chat_id then
	redis:del('Mute:Document:'..chat_id)
	locks(msg,chat_id,' قفل فایل','Mute:Document:','mutedocument:','Mutelist:')
end
-------------------------------------
if Claire == 'mutevideo:'..chat_id then
	locks(msg,chat_id,' قفل فیلم','Mute:Video:','mutevideo:','Mutelist:')
end
if Claire == 'mutevideo:kick:'..chat_id then
	redis:set('Mute:Video:'..chat_id,"Kick")
	locks(msg,chat_id,' قفل فیلم','Mute:Video:','mutevideo:','Mutelist:')
end
if Claire == 'mutevideo:warn:'..chat_id then
	redis:set('Mute:Video:'..chat_id,"Warn")
	locks(msg,chat_id,' قفل فیلم','Mute:Video:','mutevideo:','Mutelist:')
end
if Claire == 'mutevideo:mute:'..chat_id then
	redis:set('Mute:Video:'..chat_id,"Mute")
	locks(msg,chat_id,' قفل فیلم','Mute:Video:','mutevideo:','Mutelist:')
end
if Claire == 'mutevideo:enable:'..chat_id then
	redis:set('Mute:Video:'..chat_id,"Enable")
	locks(msg,chat_id,' قفل فیلم','Mute:Video:','mutevideo:','Mutelist:')
end
if Claire == 'mutevideo:disable:'..chat_id then
	redis:del('Mute:Video:'..chat_id)
	locks(msg,chat_id,' قفل فیلم','Mute:Video:','mutevideo:','Mutelist:')
end
-------------------------------------
if Claire == 'mutelocation:'..chat_id then
	locks(msg,chat_id,' قفل موقعیت مکانی','Mute:Location:','mutelocation:','Mutelist:')
end
if Claire == 'mutelocation:kick:'..chat_id then
	redis:set('Mute:Location:'..chat_id,"Kick")
	locks(msg,chat_id,' قفل موقعیت مکانی','Mute:Location:','mutelocation:','Mutelist:')
end
if Claire == 'mutelocation:warn:'..chat_id then
	redis:set('Mute:Location:'..chat_id,"Warn")
	locks(msg,chat_id,' قفل موقعیت مکانی','Mute:Location:','mutelocation:','Mutelist:')
end
if Claire == 'mutelocation:mute:'..chat_id then
	redis:set('Mute:Location:'..chat_id,"Mute")
	locks(msg,chat_id,' قفل موقعیت مکانی','Mute:Location:','mutelocation:','Mutelist:')
end
if Claire == 'mutelocation:enable:'..chat_id then
	redis:set('Mute:Location:'..chat_id,"Enable")
	locks(msg,chat_id,' قفل موقعیت مکانی','Mute:Location:','mutelocation:','Mutelist:')
end
if Claire == 'mutelocation:disable:'..chat_id then
	redis:del('Mute:Location:'..chat_id)
	locks(msg,chat_id,' قفل موقعیت مکانی','Mute:Location:','mutelocation:','Mutelist:')
end
-------------------------------------
if Claire == 'mutemusic:'..chat_id then
	locks(msg,chat_id,' قفل آهنگ','Mute:Music:','mutemusic:','Mutelist:')
end
if Claire == 'mutemusic:kick:'..chat_id then
	redis:set('Mute:Music:'..chat_id,"Kick")
	locks(msg,chat_id,' قفل آهنگ','Mute:Music:','mutemusic:','Mutelist:')
end
if Claire == 'mutemusic:warn:'..chat_id then
	redis:set('Mute:Music:'..chat_id,"Warn")
	locks(msg,chat_id,' قفل آهنگ','Mute:Music:','mutemusic:','Mutelist:')
end
if Claire == 'mutemusic:mute:'..chat_id then
	redis:set('Mute:Music:'..chat_id,"Mute")
	locks(msg,chat_id,' قفل آهنگ','Mute:Music:','mutemusic:','Mutelist:')
end
if Claire == 'mutemusic:enable:'..chat_id then
	redis:set('Mute:Music:'..chat_id,"Enable")
	locks(msg,chat_id,' قفل آهنگ','Mute:Music:','mutemusic:','Mutelist:')
end
if Claire == 'mutemusic:disable:'..chat_id then
	redis:del('Mute:Music:'..chat_id)
	locks(msg,chat_id,' قفل آهنگ','Mute:Music:','mutemusic:','Mutelist:')
end
-------------------------------------
if Claire == 'mutevoice:'..chat_id then
	locks(msg,chat_id,' قفل ویس','Mute:Voice:','mutevoice:','Mutelist:')
end
if Claire == 'mutevoice:kick:'..chat_id then
	redis:set('Mute:Voice:'..chat_id,"Kick")
	locks(msg,chat_id,' قفل ویس','Mute:Voice:','mutevoice:','Mutelist:')
end
if Claire == 'mutevoice:warn:'..chat_id then
	redis:set('Mute:Voice:'..chat_id,"Warn")
	locks(msg,chat_id,' قفل ویس','Mute:Voice:','mutevoice:','Mutelist:')
end
if Claire == 'mutevoice:mute:'..chat_id then
	redis:set('Mute:Voice:'..chat_id,"Mute")
	locks(msg,chat_id,' قفل ویس','Mute:Voice:','mutevoice:','Mutelist:')
end
if Claire == 'mutevoice:enable:'..chat_id then
	redis:set('Mute:Voice:'..chat_id,"Enable")
	locks(msg,chat_id,' قفل ویس','Mute:Voice:','mutevoice:','Mutelist:')
end
if Claire == 'mutevoice:disable:'..chat_id then
	redis:del('Mute:Voice:'..chat_id)
	locks(msg,chat_id,' قفل ویس','Mute:Voice:','mutevoice:','Mutelist:')
end
-------------------------------------
if Claire == 'mutegif:'..chat_id then
	locks(msg,chat_id,' قفل گیف','Mute:Gif:','mutegif:','Mutelist:')
end
if Claire == 'mutegif:kick:'..chat_id then
	redis:set('Mute:Gif:'..chat_id,"Kick")
	locks(msg,chat_id,' قفل گیف','Mute:Gif:','mutegif:','Mutelist:')
end
if Claire == 'mutegif:warn:'..chat_id then
	redis:set('Mute:Gif:'..chat_id,"Warn")
	locks(msg,chat_id,' قفل گیف','Mute:Gif:','mutegif:','Mutelist:')
end
if Claire == 'mutegif:mute:'..chat_id then
	redis:set('Mute:Gif:'..chat_id,"Mute")
	locks(msg,chat_id,' قفل گیف','Mute:Gif:','mutegif:','Mutelist:')
end
if Claire == 'mutegif:enable:'..chat_id then
	redis:set('Mute:Gif:'..chat_id,"Enable")
	locks(msg,chat_id,' قفل گیف','Mute:Gif:','mutegif:','Mutelist:')
end
if Claire == 'mutegif:disable:'..chat_id then
	redis:del('Mute:Gif:'..chat_id)
	locks(msg,chat_id,' قفل گیف','Mute:Gif:','mutegif:','Mutelist:')
end
-------------------------------------
if Claire == 'mutereply:'..chat_id then
	locks(msg,chat_id,' قفل ریپلی','Mute:Reply:','mutereply:','Mutelist:')
end
if Claire == 'mutereply:kick:'..chat_id then
	redis:set('Mute:Reply:'..chat_id,"Kick")
	locks(msg,chat_id,' قفل ریپلی','Mute:Reply:','mutereply:','Mutelist:')
end
if Claire == 'mutereply:warn:'..chat_id then
	redis:set('Mute:Reply:'..chat_id,"Warn")
	locks(msg,chat_id,' قفل ریپلی','Mute:Reply:','mutereply:','Mutelist:')
end
if Claire == 'mutereply:mute:'..chat_id then
	redis:set('Mute:Reply:'..chat_id,"Mute")
	locks(msg,chat_id,' قفل ریپلی','Mute:Reply:','mutereply:','Mutelist:')
end
if Claire == 'mutereply:enable:'..chat_id then
	redis:set('Mute:Reply:'..chat_id,"Enable")
	locks(msg,chat_id,' قفل ریپلی','Mute:Reply:','mutereply:','Mutelist:')
end
if Claire == 'mutereply:disable:'..chat_id then
	redis:del('Mute:Reply:'..chat_id)
	locks(msg,chat_id,' قفل ریپلی','Mute:Reply:','mutereply:','Mutelist:')
end
-------------------------------------
if Claire == 'mutecaption:'..chat_id then
	locks(msg,chat_id,' قفل رسانه','Mute:Caption:','mutecaption:','Mutelist:')
end
if Claire == 'mutecaption:kick:'..chat_id then
	redis:set('Mute:Caption:'..chat_id,"Kick")
	locks(msg,chat_id,' قفل رسانه','Mute:Caption:','mutecaption:','Mutelist:')
end
if Claire == 'mutecaption:warn:'..chat_id then
	redis:set('Mute:Caption:'..chat_id,"Warn")
	locks(msg,chat_id,' قفل رسانه','Mute:Caption:','mutecaption:','Mutelist:')
end
if Claire == 'mutecaption:mute:'..chat_id then
	redis:set('Mute:Caption:'..chat_id,"Mute")
	locks(msg,chat_id,' قفل رسانه','Mute:Caption:','mutecaption:','Mutelist:')
end
if Claire == 'mutecaption:enable:'..chat_id then
	redis:set('Mute:Caption:'..chat_id,"Enable")
	locks(msg,chat_id,' قفل رسانه','Mute:Caption:','mutecaption:','Mutelist:')
end
if Claire == 'mutecaption:disable:'..chat_id then
	redis:del('Mute:Caption:'..chat_id)
	locks(msg,chat_id,' قفل رسانه','Mute:Caption:','mutecaption:','Mutelist:')
end
----------------------------------------
if Claire == 'locktag:'..chat_id then
	locks(msg,chat_id,' قفل تگ','Lock:Tag:','locktag:','Settings:')
end
if Claire == 'locktag:kick:'..chat_id then
	redis:set('Lock:Tag:'..chat_id,"Kick")
	locks(msg,chat_id,' قفل تگ','Lock:Tag:','locktag:','Settings:')
end
if Claire == 'locktag:warn:'..chat_id then
	redis:set('Lock:Tag:'..chat_id,"Warn")
	locks(msg,chat_id,' قفل تگ','Lock:Tag:','locktag:','Settings:')
end
if Claire == 'locktag:mute:'..chat_id then
	redis:set('Lock:Tag:'..chat_id,"Mute")
	locks(msg,chat_id,' قفل تگ','Lock:Tag:','locktag:','Settings:')
end
if Claire == 'locktag:enable:'..chat_id then
	redis:set('Lock:Tag:'..chat_id,"Enable")
	locks(msg,chat_id,' قفل تگ','Lock:Tag:','locktag:','Settings:')
end
if Claire == 'locktag:disable:'..chat_id then
	redis:del('Lock:Tag:'..chat_id)
	locks(msg,chat_id,' قفل تگ','Lock:Tag:','locktag:','Settings:')
end
-------------------------------------
if Claire == 'lockhashtag:'..chat_id then
	locks(msg,chat_id,' قفل هشتگ','Lock:HashTag:','lockhashtag:','Settings:')
end
if Claire == 'lockhashtag:kick:'..chat_id then
	redis:set('Lock:HashTag:'..chat_id,"Kick")
	locks(msg,chat_id,' قفل هشتگ','Lock:HashTag:','lockhashtag:','Settings:')
end
if Claire == 'lockhashtag:warn:'..chat_id then
	redis:set('Lock:HashTag:'..chat_id,"Warn")
	locks(msg,chat_id,' قفل هشتگ','Lock:HashTag:','lockhashtag:','Settings:')
end
if Claire == 'lockhashtag:mute:'..chat_id then
	redis:set('Lock:HashTag:'..chat_id,"Mute")
	locks(msg,chat_id,' قفل هشتگ','Lock:HashTag:','lockhashtag:','Settings:')
end
if Claire == 'lockhashtag:enable:'..chat_id then
	redis:set('Lock:HashTag:'..chat_id,"Enable")
	locks(msg,chat_id,' قفل هشتگ','Lock:HashTag:','lockhashtag:','Settings:')
end
if Claire == 'lockhashtag:disable:'..chat_id then
	redis:del('Lock:HashTag:'..chat_id)
	locks(msg,chat_id,' قفل هشتگ','Lock:HashTag:','lockhashtag:','Settings:')
end
-------------------------------------
if Claire == 'lockinline:'..chat_id then 
	locks(msg,chat_id,' قفل دکمه شیشه ای','Lock:Inline:','lockinline:','Settings:')
end
if Claire == 'lockinline:kick:'..chat_id then
	redis:set('Lock:Inline:'..chat_id,"Kick")
	locks(msg,chat_id,' قفل دکمه شیشه ای','Lock:Inline:','lockinline:','Settings:')
end
if Claire == 'lockinline:warn:'..chat_id then
	redis:set('Lock:Inline:'..chat_id,"Warn")
	locks(msg,chat_id,' قفل دکمه شیشه ای','Lock:Inline:','lockinline:','Settings:')
end
if Claire == 'lockinline:mute:'..chat_id then
	redis:set('Lock:Inline:'..chat_id,"Mute")
	locks(msg,chat_id,' قفل دکمه شیشه ای','Lock:Inline:','lockinline:','Settings:')
end
if Claire == 'lockinline:enable:'..chat_id then
	redis:set('Lock:Inline:'..chat_id,"Enable")
	locks(msg,chat_id,' قفل دکمه شیشه ای','Lock:Inline:','lockinline:','Settings:')
end
if Claire == 'lockinline:disable:'..chat_id then
	redis:del('Lock:Inline:'..chat_id)
	locks(msg,chat_id,' قفل دکمه شیشه ای','Lock:Inline:','lockinline:','Settings:')
end
-------------------------------------
if Claire == 'lockvideo_note:'..chat_id then 
	locks(msg,chat_id,' قفل فیلم سلفی','Lock:Video_note:','lockvideo_note:','Settings:')
end
if Claire == 'lockvideo_note:kick:'..chat_id then
	redis:set('Lock:Video_note:'..chat_id,"Kick")
	locks(msg,chat_id,' قفل فیلم سلفی','Lock:Video_note:','lockvideo_note:','Settings:')
end
if Claire == 'lockvideo_note:warn:'..chat_id then
	redis:set('Lock:Video_note:'..chat_id,"Warn")
	locks(msg,chat_id,' قفل فیلم سلفی','Lock:Video_note:','lockvideo_note:','Settings:')
end
if Claire == 'lockvideo_note:mute:'..chat_id then
	redis:set('Lock:Video_note:'..chat_id,"Mute")
	locks(msg,chat_id,' قفل فیلم سلفی','Lock:Video_note:','lockvideo_note:','Settings:')
end
if Claire == 'lockvideo_note:enable:'..chat_id then
	redis:set('Lock:Video_note:'..chat_id,"Enable")
	locks(msg,chat_id,' قفل فیلم سلفی','Lock:Video_note:','lockvideo_note:','Settings:')
end
if Claire == 'lockvideo_note:disable:'..chat_id then
	redis:del('Lock:Video_note:'..chat_id)
	locks(msg,chat_id,' قفل فیلم سلفی','Lock:Video_note:','lockvideo_note:','Settings:')
end
-------------------------------------
if Claire == 'lockbot:'..chat_id then
if redis:get('Lock:Bot:'..chat_id) then
redis:del('Lock:Bot:'..chat_id)
Alert(TDBot.id," قفل ورود ربات غیرفعال شد")
else
redis:set('Lock:Bot:'..chat_id,true)
Alert(TDBot.id," قفل ورود ربات فعال شد")
end
setting2(msg,chat_id)
end
-------------------------------------
----------------------------------------
if Claire == 'groupinfo:'..chat_id then
local expire = redis:ttl("ExpireData:"..chat_id)
if expire == -1 then
EXPIRE = "نامحدود"
else
local d = math.floor(expire / day ) + 1
EXPIRE = d.."  روز"
end
-----
local text = ' مدیریت گروه در '..botname..''
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = ' انقضا : '..EXPIRE..'', callback_data = 'Claire'..chat_id}
},{
{text = ' لیست مدیران', callback_data = 'modlist:'..chat_id},{text = ' لیست مالکان', callback_data = 'ownerlist:'..chat_id}
},{
{text = ' لیست فیلتر', callback_data = 'filterlist:'..chat_id},
{text = ' لیست سکوت', callback_data = 'silentlist:'..chat_id}
},{
{text = ' لیست مسدود', callback_data = 'Banlist:'..chat_id}, 
{text = ' لیست ویژه', callback_data = 'Viplist:'..chat_id}
},{
{text = ' لینک گروه', callback_data = 'GroupLink:'..chat_id},{text = ' قوانین', callback_data = 'GroupRules:'..chat_id}
},{
{text = ' وضعیت خوشامد', callback_data = 'update'..chat_id}
},{
{text = ' بازگشت', callback_data = 'menugp:'..chat_id}
}}
EditInline(msg.inline_id,text,keyboard)
end
if Claire == 'ownerlist:'..chat_id then
local OwnerList = redis:smembers('OwnerList:'..chat_id)
local text = 'لیست مالکان گروه :\n'
for k,v in pairs(OwnerList) do
text = text..k.." - *"..v.."*\n" 
end
text = text.."\n برای مشاهده میتوانید از دستور زیر استفاده کنید\n"..UserBotHelper.." "..Sudoid..""
if #OwnerList == 0 then
text = ' لیست مورد نظر خالی میباشد !'
end
local keyboard = {}
keyboard.inline_keyboard = {{{text = ' بازگشت ', callback_data = 'groupinfo:'..chat_id}}}
EditInline(msg.inline_id,text,keyboard)
end
if Claire == 'Viplist:'..chat_id then
local VipList = redis:smembers('Vip:'..chat_id)
local text = 'لیست ویژه گروه :\n'
for k,v in pairs(VipList) do
text = text..k.." - `"..v.."`\n" 
end
text = text.."\n برای مشاهده میتوانید از دستور زیر استفاده کنید\n"..UserBotHelper.." "..Sudoid..""
if #VipList == 0 then
text = ' لیست مورد نظر خالی میباشد !'
local keyboard = {}
keyboard.inline_keyboard = {{{text = ' بازگشت ', callback_data = 'groupinfo:'..chat_id}}}
EditInline(msg.inline_id,text,keyboard)
else
local keyboard = {}
keyboard.inline_keyboard = {{{text = ' پاکسازی ', callback_data = 'cleanViplist:'..chat_id}},{{text = ' بازگشت ', callback_data = 'groupinfo:'..chat_id}}}
EditInline(msg.inline_id,text,keyboard)
end
end
if Claire == 'cleanViplist:'..chat_id then
local text = [[`لیست ویژه` *پاکسازی شد*]]
redis:del('Vip:'..chat_id)
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = ' بازگشت', callback_data = 'groupinfo:'..chat_id}
}}
EditInline(msg.inline_id,text,keyboard)
end
if Claire == 'modlist:'..chat_id then
local ModList = redis:smembers('ModList:'..chat_id)
local text = 'لیست مدیران گروه :\n'
for k,v in pairs(ModList) do
text = text..k.." - *"..v.."*\n" 
end
text = text.."\n برای مشاهده میتوانید از دستور زیر استفاده کنید\n"..UserBotHelper.." "..Sudoid..""
if #ModList == 0 then
text = ' لیست مورد نظر خالی میباشد !'
local keyboard = {}
keyboard.inline_keyboard = {{{text = ' بازگشت ', callback_data = 'groupinfo:'..chat_id}}}
EditInline(msg.inline_id,text,keyboard)
else
local keyboard = {}
keyboard.inline_keyboard = {{{text = ' پاکسازی ', callback_data = 'cleanmodlist:'..chat_id}},{{text = ' بازگشت ', callback_data = 'groupinfo:'..chat_id}}}
EditInline(msg.inline_id,text,keyboard)
end
end
 if Claire == 'Banlist:'..chat_id then
local BanUser = redis:smembers('BanUser:'..chat_id)
local text = 'لیست مسدودیا گروه :\n'
for k,v in pairs(BanUser) do
text = text..k.." - *"..v.."*\n" 
end
text = text.."\n برای مشاهده میتوانید از دستور زیر استفاده کنید\n"..UserBotHelper.." "..Sudoid..""
if #BanUser == 0 then
text = ' لیست مورد نظر خالی میباشد !'
local keyboard = {}
keyboard.inline_keyboard = {{{text = ' بازگشت ', callback_data = 'groupinfo:'..chat_id}}}
EditInline(msg.inline_id,text,keyboard)
else
local keyboard = {}
keyboard.inline_keyboard = {{{text = ' پاکسازی ', callback_data = 'cleanbanlist:'..chat_id}},{{text = ' بازگشت ', callback_data = 'groupinfo:'..chat_id}}}
EditInline(msg.inline_id,text,keyboard)
end
end
if Claire == 'silentlist:'..chat_id then
 local Silentlist = redis:smembers('MuteUser:'..chat_id)
 local text = 'لیست کاربران سکوت :\n'
 for k,v in pairs(Silentlist) do
 text = text..k.." - *"..v.."*\n" 
 end
text = text.."\n برای مشاهده میتوانید از دستور زیر استفاده کنید\n"..UserBotHelper.." "..Sudoid..""
  if #Silentlist == 0 then
text = ' * لیست مورد نظر خالی میباشد !*'
local keyboard = {}
keyboard.inline_keyboard = {{{text = ' بازگشت ', callback_data = 'groupinfo:'..chat_id}}}
EditInline(msg.inline_id,text,keyboard)
else
local keyboard = {}
keyboard.inline_keyboard = {{
{text = ' پاکسازی', callback_data = 'cleansilentlist:'..chat_id}},{
{text = ' بازگشت', callback_data = 'groupinfo:'..chat_id}
}}
EditInline(msg.inline_id,text,keyboard)
 end
 end
if Claire == 'cleanbanlist:'..chat_id then
local text = [[`لیست مسدود` *پاکسازی شد*]]
redis:del('BanUser:'..chat_id)
local keyboard = {}
keyboard.inline_keyboard = {{{text = ' بازگشت', callback_data = 'groupinfo:'..chat_id}}}
EditInline(msg.inline_id,text,keyboard)
end
if Claire == 'filterlist:'..chat_id then
 local Filters = redis:smembers('Filters:'..chat_id)
 local text = 'لیست کلمات فیلتر گروه :\n'
 for k,v in pairs(Filters) do
 text = text..k.." - *"..v.."*\n" 
 end
  if #Filters == 0 then
text = ' * لیست مورد نظر خالی میباشد !*'
local keyboard = {}
keyboard.inline_keyboard = {{{text = ' بازگشت ', callback_data = 'groupinfo:'..chat_id}}}
EditInline(msg.inline_id,text,keyboard)
else
local keyboard = {}
keyboard.inline_keyboard = {{
{text = ' پاکسازی', callback_data = 'cleanFilters:'..chat_id}},{
{text = ' بازگشت', callback_data = 'groupinfo:'..chat_id}
}}
EditInline(msg.inline_id,text,keyboard)
 end
 end
if Claire == 'cleanFilters:'..chat_id then
local text = [[`لیست فیلتر` *پاکسازی شد*]]
redis:del('Filters:'..chat_id)
local keyboard = {}
keyboard.inline_keyboard = {{{text = ' بازگشت', callback_data = 'groupinfo:'..chat_id}}}
EditInline(msg.inline_id,text,keyboard)
end
if Claire == 'GroupLink:'..chat_id then
local link = redis:get('Link:'..chat_id)
if link then 
local keyboard = {}
keyboard.inline_keyboard = {{
{text = ' حذف لینک ', callback_data = 'Dellink:'..chat_id}},{
{text = ' بازگشت', callback_data = 'groupinfo:'..chat_id}}}
EditInline(msg.inline_id,link,keyboard)
else
local keyboard = {}
keyboard.inline_keyboard = {{
{text = ' بازگشت', callback_data = 'groupinfo:'..chat_id}}}
EditInline(msg.inline_id,' *لینک گروه ثبت نشده است*',keyboard)
end
end
if Claire == 'Dellink:'..chat_id then
redis:del('Link:'..chat_id)
local keyboard = {}
keyboard.inline_keyboard = {{
{text = ' بازگشت', callback_data = 'groupinfo:'..chat_id}}}
EditInline(msg.inline_id,' *لینک گروه حذف شد*',keyboard)
end
if Claire == 'GroupRules:'..chat_id then
local rules = redis:get('Rules:'..chat_id)
if rules then 
local keyboard = {}
keyboard.inline_keyboard = {{
{text = ' حذف قوانین ', callback_data = 'Delrules:'..chat_id}},{
{text = ' بازگشت', callback_data = 'groupinfo:'..chat_id}}}
EditInline(msg.inline_id,rules,keyboard)
else
local keyboard = {}
keyboard.inline_keyboard = {{
{text = ' بازگشت', callback_data = 'groupinfo:'..chat_id}}}
EditInline(msg.inline_id,' *قوانین گروه ثبت نشده است*',keyboard)
end
end
if Claire == 'Delrules:'..chat_id then
redis:del('Rules:'..chat_id)
local keyboard = {}
keyboard.inline_keyboard = {{
{text = ' بازگشت', callback_data = 'groupinfo:'..chat_id}}}
EditInline(msg.inline_id,' *قوانین گروه حذف شد*',keyboard)
end
---------------------------------------------------------------
if Claire == 'automuteall:'..chat_id then
if redis:get('automuteall'..chat_id) then
redis:del('automuteall'..chat_id)
Alert(TDBot.id, " قفل خودکار غیرفعال شد")
else
redis:set('automuteall'..chat_id,true)
Alert(TDBot.id, " قفل خودکار فعال شد")
end
setting1(msg,chat_id)
end
if Claire == 'lockflood:'..chat_id then
if redis:get('Lock:Flood:'..chat_id) then
redis:del('Lock:Flood:'..chat_id)
 Alert(TDBot.id, " قفل فلود غیرفعال شد")
else
redis:set('Lock:Flood:'..chat_id,true)
Alert(TDBot.id, " قفل فلود فعال شد")
end
setting1(msg,chat_id)
end
if Claire == 'lockspam:'..chat_id then
if redis:get('Spam:Lock:'..chat_id) then
redis:del('Spam:Lock:'..chat_id)
 Alert(TDBot.id, " قفل اسپم غیرفعال شد ")
else
redis:set('Spam:Lock:'..chat_id,true)
Alert(TDBot.id, " قفل اسپم فعال شد")
end
setting1(msg,chat_id)
end
if Claire == 'lockadd:'..chat_id then
if redis:get('forceAdd:'..chat_id) then
redis:del('forceAdd:'..chat_id)
 Alert(TDBot.id, " وضعیت اداجباری غیرفعال شد ")
else
redis:set('forceAdd:'..chat_id,true)
Alert(TDBot.id, "وضعیت اداجباری فعال شد")
end
setting3(msg,chat_id)
end
if Claire == 'lockcommand:'..chat_id then
if redis:get('Lock:Cmd'..chat_id) then
redis:del('Lock:Cmd'..chat_id)
 Alert(TDBot.id, " قفل دستورات برای کاربر عادی غیر فعال شد")
else
redis:set('Lock:Cmd'..chat_id,true)
Alert(TDBot.id, " قفل دستورات برای کاربر عادی فعال شد")
end
setting1(msg,chat_id)
end
if Claire == 'muteall:'..chat_id then
if redis:get('MuteAll:'..chat_id) then
redis:del('MuteAll:'..chat_id)
 Alert(TDBot.id, " قفل گروه غیرفعال شد")
else
redis:set('MuteAll:'..chat_id,true)
Alert(TDBot.id, " قفل گروه فعال شد")
end
setting1(msg,chat_id)
end
if Claire == 'MSGMAXup:'..chat_id then
if tonumber(MSG_MAX) == 15 then
Alert(TDBot.id,'حداکثر مقدار 15' ,true)
else
MSG_MAX = (redis:get('Flood:Max:'..chat_id) or 6)
MSG_MAX = tonumber(MSG_MAX) + 1
Alert(TDBot.id,MSG_MAX)
redis:set('Flood:Max:'..chat_id,MSG_MAX)
end
setting3(msg,chat_id)
end
if Claire == 'MSGMAXdown:'..chat_id then
if tonumber(MSG_MAX) == 3 then
Alert(TDBot.id,'حداقل مقدار 3' ,true)
else
MSG_MAX = (redis:get('Flood:Max:'..chat_id) or 6)
MSG_MAX = tonumber(MSG_MAX) - 1
Alert(TDBot.id,MSG_MAX)
redis:set('Flood:Max:'..chat_id,MSG_MAX)
end
setting3(msg,chat_id)
end
if Claire == 'TIMEMAXup:'..chat_id then
if tonumber(TIME_CHECK) == 9 then
Alert(TDBot.id,'حداکثر مقدار 9')
else
TIME_CHECK = (redis:get('Flood:Time:'..chat_id) or 2)
TIME_CHECK = tonumber(TIME_CHECK) + 1
Alert(TDBot.id,TIME_CHECK)
redis:set('Flood:Time:'..chat_id,TIME_CHECK)
end
setting3(msg,chat_id)
end
if Claire == 'TIMEMAXdown:'..chat_id then
if tonumber(TIME_CHECK) == 2 then
Alert(TDBot.id,'حداقل مقدار 2' ,true)
else
TIME_CHECK = (redis:get('Flood:Time:'..chat_id) or 2)
TIME_CHECK = tonumber(TIME_CHECK) - 1
Alert(TDBot.id,TIME_CHECK)
redis:set('Flood:Time:'..chat_id,TIME_CHECK)
end
setting3(msg,chat_id)
end
if Claire == 'Force_Timeup:'..chat_id then
if tonumber(Force_Time) == 200 then
Alert(TDBot.id,'حداکثر مقدار 200')
else
Force_Time = (redis:get('force:Time:'..chat_id) or 50)
Force_Time = tonumber(Force_Time) + 1
Alert(TDBot.id,Force_Time)
redis:set('force:Time:'..chat_id,Force_Time)
end
setting3(msg,chat_id)
end
if Claire == 'Force_Timedown:'..chat_id then
if tonumber(Force_Time) == 50 then
Alert(TDBot.id,'حداقل مقدار  50' ,true)
else
Force_Time = (redis:get('force:Time:'..chat_id) or 50)
Force_Time = tonumber(Force_Time) - 1
Alert(TDBot.id,Force_Time)
redis:set('force:Time:'..chat_id,Force_Time)
end
setting3(msg,chat_id)
end
if Claire == 'Warn_Maxup:'..chat_id then
if tonumber(Warn_Max) == 200 then
Alert(TDBot.id,'حداکثر مقدار 200')
else
Warn_Max = (redis:get('Warn:Max:'..chat_id) or 1)
Warn_Max = tonumber(Warn_Max) + 1
Alert(TDBot.id,Warn_Max)
redis:set('Warn:Max:'..chat_id,Warn_Max)
end
setting3(msg,chat_id)
end
if Claire == 'Warn_Maxdown:'..chat_id then
if tonumber(Warn_Max) == 1 then
Alert(TDBot.id,'حداقل مقدار  1' ,true)
else
Warn_Max = (redis:get('Warn:Max:'..chat_id) or 1)
Warn_Max = tonumber(Warn_Max) - 1
Alert(TDBot.id,Warn_Max)
redis:set('Warn:Max:'..chat_id,Warn_Max)
end
setting3(msg,chat_id)
end
if Claire == 'Force_Maxup:'..chat_id then
if tonumber(Force_Max) == 200 then
Alert(TDBot.id,'حداکثر مقدار 200')
else
Force_Max = (redis:get('force:Max:'..chat_id) or 2)
Force_Max = tonumber(Force_Max) + 1
Alert(TDBot.id,Force_Max)
redis:set('force:Max:'..chat_id,Force_Max)
end
setting3(msg,chat_id)
end
if Claire == 'Force_Maxdown:'..chat_id then
if tonumber(Force_Max) == 2 then
Alert(TDBot.id,'حداقل مقدار 2' ,true)
else
Force_Max = (redis:get('force:Max:'..chat_id) or 2)
Force_Max = tonumber(Force_Max) - 1
Alert(TDBot.id,Force_Max)
redis:set('force:Max:'..chat_id,Force_Max)
end
setting3(msg,chat_id)
end
if Claire == 'CHMAXup:'..chat_id then
if tonumber(CH_MAX) == 4096 then
Alert(TDBot.id,'حداکثر مقدار 4096' ,true)
else
CH_MAX = (redis:get('NUM_CH_MAX:'..chat_id) or 200)
CH_MAX= tonumber(CH_MAX) + 50
Alert(TDBot.id,CH_MAX)
redis:set('NUM_CH_MAX:'..chat_id,CH_MAX)
end
setting3(msg,chat_id)
end
if Claire == 'CHMAXdown:'..chat_id then
if tonumber(CH_MAX) == 50 then
Alert(TDBot.id,'حداقل مقدار 50' ,true)
else
CH_MAX = (redis:get('NUM_CH_MAX:'..chat_id) or 200)
CH_MAX= tonumber(CH_MAX) - 50
Alert(TDBot.id,CH_MAX)
redis:set('NUM_CH_MAX:'..chat_id,CH_MAX)
end
setting3(msg,chat_id)
end
if Claire == 'floodstatus:'..chat_id then
local hash = redis:get('Flood:Status:'..chat_id)
if hash then
if redis:get('Flood:Status:'..chat_id) == 'kickuser' then
redis:set('Flood:Status:'..chat_id,'muteuser')
Status = 'سکوت کاربر'
Alert(TDBot.id,'وضعیت فلود بر روی '..Status..' قرار گرفت')
elseif redis:get('Flood:Status:'..chat_id) == 'muteuser' then
redis:set('Flood:Status:'..chat_id,'deletemsg')
Status = 'حذف پیام'
Alert(TDBot.id,'وضعیت فلود بر روی '..Status..' قرار گرفت')
elseif redis:get('Flood:Status:'..chat_id) == 'deletemsg' then
redis:del('Flood:Status:'..chat_id)
Status = 'تنظیم نشده'
Alert(TDBot.id,'وضعیت فلود بر روی '..Status..' قرار گرفت')
end
else
redis:set('Flood:Status:'..chat_id,'kickuser')
Status = 'اخراج کاربر'
Alert(TDBot.id,'وضعیت فلود بر روی '..Status..' قرار گرفت')
end
setting3(msg,chat_id)
end
------------------------------------------------------
end --Alert not mod
end --Alert Claire
-----------------End Mod---------------
----------------Start Owner ----------------------
if not is_Mod(chat_id,TDBot.from.id) then
Alert(TDBot.id,' کاربر '..msg.user_first..' شما دسترسی کافی ندارید')
else
if Claire == 'cleanmodlist:'..chat_id then
local text = [[`لیست مدیران`  *پاکسازی شد*]]
redis:del('ModList:'..chat_id)
local keyboard = {}
keyboard.inline_keyboard = {
{
{text = ' بازگشت', callback_data = 'groupinfo:'..chat_id}
}}
EditInline(msg.inline_id,text,keyboard)
end
if Claire == 'lockpin'..chat_id then
if redis:get('Lock:Pin:'..chat_id) then
redis:del('Lock:Pin:'..chat_id)
Alert(TDBot.id, " قفل سنجاق غیرفعال شد !")
else
redis:set('Lock:Pin:'..chat_id,true)
Alert(TDBot.id, " قفل  سنجاق فعال  شد ً!")
end
setting1(msg,chat_id)
end
-----------------------
end -- Alert not Owner
-----------------
if msg.message and msg.message.date < tonumber(MsgTime) then
print('OLD MESSAGE')
 return false
end
end
end
end
end
end
return Running()
